<?php
require_once '../includes/config.php';
require_once '../includes/supabase.php';

// Get session code from URL
$sessionCode = isset($_GET['code']) ? strtoupper(trim($_GET['code'])) : '';

// Validate session code format (6 characters)
if ($sessionCode && !preg_match('/^[A-Z0-9]{6}$/', $sessionCode)) {
    $error = "Invalid session code format";
    $sessionCode = '';
}

$pageTitle = "Autrex Remote Control";
$lang = isset($lang) ? $lang : 'en';
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $pageTitle; ?></title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Supabase JS -->
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
    
    <!-- HTML5 QR Code Scanner -->
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Spiegel:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Spiegel', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0a1428 0%, #0d1b2a 50%, #1b2838 100%);
            min-height: 100vh;
            color: #f0e6d2;
            overflow-x: hidden;
        }
        
        /* LoL Style Background Pattern */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: 
                radial-gradient(circle at 20% 50%, rgba(200, 170, 110, 0.03) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(120, 110, 180, 0.03) 0%, transparent 50%),
                radial-gradient(circle at 50% 20%, rgba(139, 69, 255, 0.02) 0%, transparent 50%);
            pointer-events: none;
            z-index: 0;
        }
        
        .container {
            position: relative;
            z-index: 1;
            max-width: 420px;
            margin: 0 auto;
            padding: 12px;
            min-height: 100vh;
        }
        
        @media (max-width: 480px) {
            .container {
                padding: 10px;
                max-width: 100%;
            }
        }
        
        /* Autrex Logo */
        .autrex-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        
        .autrex-logo-text {
            font-size: 28px;
            font-weight: 700;
            background: linear-gradient(135deg, #8b45ff 0%, #c8aa6e 50%, #8b45ff 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-transform: uppercase;
            letter-spacing: 3px;
        }
        
        .autrex-badge {
            display: inline-block;
            padding: 4px 12px;
            background: linear-gradient(135deg, rgba(139, 69, 255, 0.2) 0%, rgba(200, 170, 110, 0.2) 100%);
            border: 1px solid rgba(139, 69, 255, 0.3);
            border-radius: 12px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #8b45ff;
        }
        
        @media (max-width: 480px) {
            .autrex-logo {
                gap: 8px;
                margin-bottom: 12px;
            }
            
            .autrex-logo-text {
                font-size: 24px;
                letter-spacing: 2px;
            }
            
            .autrex-badge {
                font-size: 9px;
                padding: 3px 10px;
            }
        }

        
        /* LoL Style Card */
        .lol-card {
            background: linear-gradient(135deg, rgba(1, 10, 19, 0.95) 0%, rgba(5, 15, 25, 0.95) 100%);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 12px;
            box-shadow: 
                0 0 30px rgba(0, 0, 0, 0.5),
                inset 0 1px 0 rgba(200, 170, 110, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .lol-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(200, 170, 110, 0.5), transparent);
        }
        
        /* Header Styles */
        .lol-header {
            background: linear-gradient(135deg, rgba(200, 170, 110, 0.1) 0%, rgba(139, 69, 255, 0.1) 100%);
            border-bottom: 1px solid rgba(200, 170, 110, 0.2);
            padding: 24px;
            text-align: center;
        }
        
        .lol-title {
            font-size: 32px;
            font-weight: 700;
            background: linear-gradient(135deg, #c8aa6e 0%, #f0e6d2 50%, #c8aa6e 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 8px;
            text-shadow: 0 0 20px rgba(200, 170, 110, 0.3);
        }
        
        .lol-subtitle {
            color: #a09b8c;
            font-size: 14px;
            letter-spacing: 1px;
        }
        
        /* Session Code Input Screen Styles */
        .session-input-container {
            min-height: 70vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .session-hero {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .session-hero-icon {
            font-size: 80px;
            margin-bottom: 20px;
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        .session-hero-title {
            font-size: 36px;
            font-weight: 700;
            background: linear-gradient(135deg, #c8aa6e 0%, #8b45ff 50%, #c8aa6e 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-transform: uppercase;
            letter-spacing: 3px;
            margin-bottom: 12px;
            line-height: 1.2;
        }
        
        .session-hero-subtitle {
            color: #a09b8c;
            font-size: 16px;
            line-height: 1.6;
            max-width: 400px;
            margin: 0 auto;
        }
        
        /* Code Input Boxes */
        .code-input-wrapper {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-bottom: 24px;
        }
        
        .code-input-box {
            width: 50px;
            height: 60px;
            background: rgba(0, 0, 0, 0.4);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 8px;
            font-size: 32px;
            font-weight: 700;
            text-align: center;
            color: #f0e6d2;
            text-transform: uppercase;
            font-family: 'Courier New', monospace;
            transition: all 0.3s ease;
        }
        
        .code-input-box:focus {
            outline: none;
            border-color: #c8aa6e;
            box-shadow: 0 0 20px rgba(200, 170, 110, 0.4);
            background: rgba(0, 0, 0, 0.6);
            transform: scale(1.05);
        }
        
        .code-input-box.filled {
            border-color: #0ac8b9;
            background: rgba(10, 200, 185, 0.1);
        }
        
        /* Mobile responsive */
        @media (max-width: 480px) {
            .code-input-box {
                width: 45px;
                height: 55px;
                font-size: 28px;
            }
            
            .session-hero-icon {
                font-size: 60px;
            }
            
            .session-hero-title {
                font-size: 28px;
            }
        }
        
        /* Legacy input (hidden, for form submission) */
        .lol-input {
            display: none;
        }
        
        /* Button Styles */
        .lol-button {
            background: linear-gradient(135deg, #c8aa6e 0%, #8b7355 100%);
            border: 2px solid #785a28;
            color: #0a1428;
            font-size: 18px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 2px;
            padding: 16px 32px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(200, 170, 110, 0.3);
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
            min-height: 56px;
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            display: block;
        }
        
        .lol-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
        }
        
        /* Desktop hover */
        @media (hover: hover) {
            .lol-button:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(200, 170, 110, 0.4);
                border-color: #c8aa6e;
            }
            
            .lol-button:hover::before {
                left: 100%;
            }
        }
        
        /* Mobile tap */
        .lol-button:active {
            transform: scale(0.95);
        }
        
        @media (max-width: 480px) {
            .lol-button {
                font-size: 16px;
                padding: 14px 24px;
                min-height: 52px;
            }
        }
        
        /* Status Badge */
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: rgba(0, 0, 0, 0.4);
            border: 1px solid rgba(200, 170, 110, 0.3);
            border-radius: 20px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        .status-dot.connected {
            background: #0ac8b9;
            box-shadow: 0 0 10px #0ac8b9;
        }
        
        .status-dot.disconnected {
            background: #e84057;
            box-shadow: 0 0 10px #e84057;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.6; transform: scale(0.9); }
        }
        
        @keyframes hourglass {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(180deg); }
        }
        
        .hourglass-animate {
            animation: hourglass 2s ease-in-out infinite;
            display: inline-block;
        }
        
        /* Session Code Display */
        .session-code {
            font-family: 'Courier New', monospace;
            font-size: 36px;
            font-weight: 700;
            letter-spacing: 6px;
            color: #c8aa6e;
            text-shadow: 0 0 20px rgba(200, 170, 110, 0.5);
        }
        
        /* Game Status Card */
        .game-status-card {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px;
            background: linear-gradient(135deg, rgba(200, 170, 110, 0.1) 0%, rgba(139, 69, 255, 0.1) 100%);
            border: 1px solid rgba(200, 170, 110, 0.3);
            border-radius: 8px;
        }
        
        .game-status-icon {
            font-size: 36px;
            flex-shrink: 0;
        }
        
        .game-status-text {
            flex: 1;
            min-width: 0; /* Allow text truncation */
        }
        
        .game-status-text h3 {
            font-size: 18px;
            font-weight: 700;
            color: #c8aa6e;
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .game-status-text p {
            font-size: 12px;
            color: #a09b8c;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        @media (max-width: 480px) {
            .game-status-card {
                padding: 14px;
                gap: 12px;
            }
            
            .game-status-icon {
                font-size: 32px;
            }
            
            .game-status-text h3 {
                font-size: 16px;
            }
            
            .game-status-text p {
                font-size: 11px;
            }
        }
        
        /* Action Mode Tabs */
        .action-tabs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-bottom: 12px;
        }
        
        .action-tab {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            padding: 12px 8px;
            background: rgba(0, 0, 0, 0.3);
            border: 2px solid rgba(200, 170, 110, 0.2);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
        }
        
        .action-tab:active {
            transform: scale(0.95);
        }
        
        .action-tab.active {
            background: linear-gradient(135deg, rgba(200, 170, 110, 0.2) 0%, rgba(139, 69, 255, 0.2) 100%);
            border-color: #c8aa6e;
            box-shadow: 0 0 20px rgba(200, 170, 110, 0.3);
        }
        
        .action-tab-icon {
            font-size: 24px;
        }
        
        .action-tab-text {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #f0e6d2;
        }
        
        .action-tab-badge {
            font-size: 9px;
            padding: 3px 6px;
            background: rgba(0, 0, 0, 0.4);
            border-radius: 6px;
            color: #a09b8c;
            white-space: nowrap;
        }
        
        .action-tab.active .action-tab-badge {
            background: rgba(200, 170, 110, 0.3);
            color: #c8aa6e;
        }
        
        @media (max-width: 480px) {
            .action-tabs {
                gap: 6px;
            }
            
            .action-tab {
                padding: 10px 6px;
                gap: 4px;
            }
            
            .action-tab-icon {
                font-size: 20px;
            }
            
            .action-tab-text {
                font-size: 11px;
            }
            
            .action-tab-badge {
                font-size: 8px;
                padding: 2px 5px;
            }
        }

        
        /* Champion Grid */
        .champion-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(56px, 1fr));
            gap: 8px;
            max-height: 45vh;
            overflow-y: auto;
            padding: 6px;
            -webkit-overflow-scrolling: touch; /* Smooth scrolling on iOS */
            transition: opacity 0.3s ease;
        }
        
        @media (max-width: 480px) {
            .champion-grid {
                grid-template-columns: repeat(auto-fill, minmax(52px, 1fr));
                gap: 6px;
                max-height: 40vh;
                padding: 4px;
            }
        }
        
        .champion-grid::-webkit-scrollbar {
            width: 8px;
        }
        
        .champion-grid::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.3);
            border-radius: 4px;
        }
        
        .champion-grid::-webkit-scrollbar-thumb {
            background: rgba(200, 170, 110, 0.3);
            border-radius: 4px;
        }
        
        .champion-grid::-webkit-scrollbar-thumb:hover {
            background: rgba(200, 170, 110, 0.5);
        }
        
        .champion-card {
            aspect-ratio: 1;
            border-radius: 8px;
            overflow: hidden;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid rgba(200, 170, 110, 0.2);
            position: relative;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
        }
        
        .champion-card::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, transparent 0%, rgba(200, 170, 110, 0.1) 100%);
            opacity: 0;
            transition: opacity 0.2s ease;
        }
        
        /* Desktop hover */
        @media (hover: hover) {
            .champion-card:hover {
                transform: scale(1.05);
                border-color: #c8aa6e;
                box-shadow: 0 0 15px rgba(200, 170, 110, 0.5);
            }
            
            .champion-card:hover::after {
                opacity: 1;
            }
        }
        
        /* Mobile tap */
        .champion-card:active {
            transform: scale(0.95);
        }
        
        .champion-card.selected {
            border-color: #0ac8b9;
            border-width: 4px;
            box-shadow: 
                0 0 30px rgba(10, 200, 185, 0.8),
                inset 0 0 20px rgba(10, 200, 185, 0.3);
            transform: scale(1.1);
            z-index: 10;
        }
        
        .champion-card.selected::after {
            opacity: 1;
            background: linear-gradient(135deg, transparent 0%, rgba(10, 200, 185, 0.3) 100%);
        }
        
        /* Disabled champion (already picked) */
        .champion-card.disabled {
            opacity: 0.3;
            filter: grayscale(100%);
            cursor: not-allowed;
            pointer-events: none;
        }
        
        .champion-card.disabled::after {
            content: '✓';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 32px;
            color: #0ac8b9;
            text-shadow: 0 0 8px rgba(0, 0, 0, 0.8);
            font-weight: 700;
        }
        
        .champion-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            pointer-events: none; /* Prevent image drag on mobile */
        }
        
        /* Action Buttons */
        .action-button {
            padding: 16px 24px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid;
            position: relative;
            overflow: hidden;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
            min-height: 56px; /* Better touch target size */
        }
        
        .action-button.ban {
            background: linear-gradient(135deg, #e84057 0%, #c41e3a 100%);
            border-color: #8b1a2e;
            color: #fff;
        }
        
        .action-button.pick {
            background: linear-gradient(135deg, #0ac8b9 0%, #0397ab 100%);
            border-color: #026b7a;
            color: #fff;
        }
        
        .action-button:disabled {
            opacity: 0.4;
            cursor: not-allowed;
            transform: none !important;
        }
        
        /* Desktop hover */
        @media (hover: hover) {
            .action-button:not(:disabled):hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
            }
        }
        
        /* Mobile tap */
        .action-button:not(:disabled):active {
            transform: scale(0.95);
        }
        
        @media (max-width: 480px) {
            .action-button {
                padding: 14px 20px;
                font-size: 16px;
                min-height: 52px;
            }
        }
        
        /* Error Message */
        .error-message {
            background: rgba(232, 64, 87, 0.2);
            border: 1px solid #e84057;
            border-radius: 8px;
            padding: 16px;
            color: #ff6b7a;
            font-size: 14px;
        }
        
        /* Success Message */
        .success-message {
            background: rgba(10, 200, 185, 0.2);
            border: 1px solid #0ac8b9;
            border-radius: 8px;
            padding: 16px;
            color: #0ac8b9;
            font-size: 14px;
            text-align: center;
        }
        
        /* Trade Notifications */
        .trade-notifications {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1000;
            display: flex;
            flex-direction: column;
            gap: 12px;
            max-width: 350px;
        }
        
        @media (max-width: 480px) {
            .trade-notifications {
                top: 70px;
                right: 10px;
                left: 10px;
                max-width: none;
            }
        }
        
        .trade-card {
            background: linear-gradient(135deg, rgba(1, 10, 19, 0.98) 0%, rgba(5, 15, 25, 0.98) 100%);
            border: 2px solid rgba(200, 170, 110, 0.4);
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8);
            animation: slideInRight 0.3s ease;
        }
        
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(100%);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes slideOutRight {
            from {
                opacity: 1;
                transform: translateX(0);
            }
            to {
                opacity: 0;
                transform: translateX(100%);
            }
        }
        
        .trade-card.incoming {
            border-color: rgba(10, 200, 185, 0.6);
        }
        
        .trade-card.outgoing {
            border-color: rgba(139, 69, 255, 0.6);
        }
        
        .trade-header {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
        }
        
        .trade-icon {
            font-size: 24px;
        }
        
        .trade-title {
            flex: 1;
            font-size: 14px;
            font-weight: 700;
            color: #c8aa6e;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .trade-body {
            font-size: 13px;
            color: #f0e6d2;
            margin-bottom: 12px;
            line-height: 1.5;
        }
        
        .trade-from {
            color: #0ac8b9;
            font-weight: 700;
        }
        
        .trade-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }
        
        .trade-btn {
            padding: 10px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
        }
        
        .trade-btn-accept {
            background: linear-gradient(135deg, #0ac8b9 0%, #0397ab 100%);
            border-color: #026b7a;
            color: #fff;
        }
        
        .trade-btn-decline {
            background: linear-gradient(135deg, #e84057 0%, #c41e3a 100%);
            border-color: #8b1a2e;
            color: #fff;
        }
        
        .trade-btn:active {
            transform: scale(0.95);
        }
        
        .trade-timer {
            text-align: center;
            margin-top: 8px;
            font-size: 11px;
            color: #f0ad4e;
            font-family: 'Courier New', monospace;
            font-weight: 700;
        }
        
        /* Footer */
        .autrex-footer {
            text-align: center;
            padding: 20px 16px;
            color: #5b5a56;
            font-size: 12px;
            line-height: 1.6;
        }
        
        .autrex-footer a {
            color: #8b45ff;
            text-decoration: none;
            font-weight: 600;
            -webkit-tap-highlight-color: transparent;
        }
        
        .autrex-footer a:hover {
            color: #c8aa6e;
        }
        
        @media (max-width: 480px) {
            .autrex-footer {
                padding: 16px 12px;
                font-size: 11px;
            }
        }
        
        /* Search Input */
        #championSearch {
            width: 100%;
            padding: 14px 16px;
            background: rgba(0, 0, 0, 0.4);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 8px;
            color: #f0e6d2;
            font-size: 15px;
            transition: all 0.3s ease;
            -webkit-appearance: none;
        }
        
        #championSearch:focus {
            outline: none;
            border-color: #c8aa6e;
            box-shadow: 0 0 15px rgba(200, 170, 110, 0.3);
            background: rgba(0, 0, 0, 0.6);
        }
        
        #championSearch::placeholder {
            color: rgba(160, 155, 140, 0.6);
        }
        
        @media (max-width: 480px) {
            #championSearch {
                padding: 12px 14px;
                font-size: 14px;
            }
        }
        
        /* Spacing */
        .space-y-4 > * + * {
            margin-top: 16px;
        }
        
        @media (max-width: 480px) {
            .space-y-4 > * + * {
                margin-top: 12px;
            }
        }
        
        .mb-4 {
            margin-bottom: 16px;
        }
        
        .p-6 {
            padding: 24px;
        }
        
        @media (max-width: 480px) {
            .p-6 {
                padding: 16px;
            }
        }
        
        .hidden {
            display: none;
        }
        
        /* Prevent zoom on input focus (iOS) */
        @media (max-width: 480px) {
            input, select, textarea {
                font-size: 16px !important;
            }
        }
        
        /* Position Select Dropdown */
        .position-select {
            width: 100%;
            padding: 10px 12px;
            background: rgba(0, 0, 0, 0.4);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 6px;
            color: #f0e6d2;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23c8aa6e' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 36px;
        }
        
        .position-select:focus {
            outline: none;
            border-color: #c8aa6e;
            box-shadow: 0 0 12px rgba(200, 170, 110, 0.4);
            background-color: rgba(0, 0, 0, 0.6);
        }
        
        .position-select option {
            background: #0a1428;
            color: #f0e6d2;
            padding: 8px;
        }
        
        /* Position Icons */
        .position-icon {
            width: 20px;
            height: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 4px;
            border: 1px solid rgba(200, 170, 110, 0.3);
            padding: 2px;
        }
        
        .position-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        
        .position-icon-large {
            width: 40px;
            height: 40px;
        }
        
        .position-icon-large img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            filter: drop-shadow(0 0 4px rgba(200, 170, 110, 0.5));
        }
        
        /* Position change animation */
        @keyframes positionChange {
            0% {
                transform: scale(1);
                opacity: 1;
            }
            50% {
                transform: scale(1.2);
                opacity: 0.7;
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
        
        .position-changed {
            animation: positionChange 0.6s ease-in-out;
        }
        
        @keyframes slideInFromTop {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        #yourPosition.position-updated {
            animation: slideInFromTop 0.5s ease-out;
        }
        
        /* Team Member Cards (Compact Mobile) */
        .team-member {
            position: relative;
            width: 48px;
            height: 48px;
            border-radius: 6px;
            overflow: visible;
            border: 2px solid rgba(200, 170, 110, 0.3);
            background: rgba(0, 0, 0, 0.4);
        }
        
        .team-member-wrapper {
            position: relative;
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            gap: 2px;
            margin-bottom: 32px; /* Space for trade button and role text */
        }
        
        .team-member-name {
            font-size: 9px;
            color: #a09b8c;
            text-align: center;
            max-width: 60px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .team-member-name.local-player {
            color: #0ac8b9;
            font-weight: 700;
        }
        
        .team-member-role {
            font-size: 8px;
            color: #c8aa6e;
            text-align: center;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-top: -2px;
        }
        
        .team-member-lock-indicator {
            position: absolute;
            bottom: 2px;
            right: 2px;
            width: 16px;
            height: 16px;
            background: rgba(10, 200, 185, 0.9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            border: 2px solid #0a1428;
            z-index: 5;
        }
        
        .team-member-hover-indicator {
            position: absolute;
            top: 2px;
            left: 2px;
            font-size: 12px;
            filter: drop-shadow(0 0 4px rgba(0, 0, 0, 0.8));
            z-index: 5;
            animation: pulse 1.5s infinite;
        }
        
        .team-member-position {
            position: absolute;
            top: -6px;
            right: -6px;
            z-index: 10;
        }
        
        /* Pick order badge */
        .pick-order-badge {
            position: absolute;
            top: -8px;
            left: -8px;
            width: 20px;
            height: 20px;
            background: linear-gradient(135deg, #c8aa6e 0%, #8b7355 100%);
            border: 2px solid #0a1428;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            font-weight: 700;
            color: #0a1428;
            z-index: 15;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
        }
        
        .team-member.active {
            border-color: #0ac8b9;
            box-shadow: 0 0 12px rgba(10, 200, 185, 0.6);
            animation: pulse-border 1.5s infinite;
        }
        
        @keyframes pulse-border {
            0%, 100% { border-color: #0ac8b9; }
            50% { border-color: #0de9d7; }
        }
        
        /* Pulsing glow for current picker */
        .team-member.picking {
            border-color: #f0ad4e;
            box-shadow: 0 0 25px rgba(240, 173, 78, 1), 0 0 40px rgba(240, 173, 78, 0.6);
            animation: pulse-picker 0.8s infinite;
            transform: scale(1.05);
        }
        
        .team-member-placeholder.picking {
            border-color: #f0ad4e;
            box-shadow: 0 0 25px rgba(240, 173, 78, 1), 0 0 40px rgba(240, 173, 78, 0.6);
            animation: pulse-picker 0.8s infinite;
            transform: scale(1.05);
        }
        
        @keyframes pulse-picker {
            0%, 100% {
                border-color: #f0ad4e;
                box-shadow: 0 0 25px rgba(240, 173, 78, 1), 0 0 40px rgba(240, 173, 78, 0.6);
                transform: scale(1.05);
            }
            50% {
                border-color: #ffc107;
                box-shadow: 0 0 35px rgba(255, 193, 7, 1), 0 0 50px rgba(255, 193, 7, 0.8);
                transform: scale(1.08);
            }
        }
        
        /* Your Turn Indicator (Full Screen) */
        .your-turn-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(10, 20, 40, 0.95);
            z-index: 9998;
            display: none;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .your-turn-overlay.active {
            display: flex;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .your-turn-content {
            text-align: center;
            padding: 40px;
            max-width: 90%;
        }
        
        .your-turn-pulse {
            width: 120px;
            height: 120px;
            margin: 0 auto 30px;
            background: linear-gradient(135deg, #0ac8b9 0%, #0397ab 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 60px;
            animation: pulse-turn 1.5s infinite;
            box-shadow: 0 0 40px rgba(10, 200, 185, 0.6);
        }
        
        @keyframes pulse-turn {
            0%, 100% {
                transform: scale(1);
                box-shadow: 0 0 40px rgba(10, 200, 185, 0.6);
            }
            50% {
                transform: scale(1.1);
                box-shadow: 0 0 60px rgba(10, 200, 185, 0.9);
            }
        }
        
        .your-turn-title {
            font-size: 48px;
            font-weight: 700;
            background: linear-gradient(135deg, #0ac8b9 0%, #0de9d7 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-transform: uppercase;
            letter-spacing: 4px;
            margin-bottom: 16px;
            animation: glow-text 2s infinite;
        }
        
        @keyframes glow-text {
            0%, 100% { filter: drop-shadow(0 0 10px rgba(10, 200, 185, 0.5)); }
            50% { filter: drop-shadow(0 0 20px rgba(10, 200, 185, 0.8)); }
        }
        
        .your-turn-subtitle {
            font-size: 18px;
            color: #a09b8c;
            margin-bottom: 24px;
        }
        
        .your-turn-timer {
            font-size: 32px;
            font-weight: 700;
            color: #f0ad4e;
            font-family: 'Courier New', monospace;
        }
        
        .your-turn-dismiss {
            margin-top: 30px;
            padding: 12px 24px;
            background: rgba(200, 170, 110, 0.2);
            border: 2px solid rgba(200, 170, 110, 0.5);
            border-radius: 8px;
            color: #c8aa6e;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .your-turn-dismiss:hover {
            background: rgba(200, 170, 110, 0.3);
            border-color: #c8aa6e;
        }
        
        @media (max-width: 480px) {
            .your-turn-pulse {
                width: 100px;
                height: 100px;
                font-size: 50px;
                margin-bottom: 24px;
            }
            
            .your-turn-title {
                font-size: 36px;
                letter-spacing: 3px;
            }
            
            .your-turn-subtitle {
                font-size: 16px;
            }
            
            .your-turn-timer {
                font-size: 28px;
            }
        }
        
        .team-member img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .team-member.banned {
            opacity: 0.4;
            filter: grayscale(100%);
        }
        
        .team-member.banned::after {
            content: '🚫';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 20px;
        }
        
        .team-member-placeholder {
            width: 48px;
            height: 48px;
            border-radius: 6px;
            border: 2px dashed rgba(200, 170, 110, 0.2);
            background: rgba(0, 0, 0, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            opacity: 0.5;
        }
        
        /* Trade Button */
        .trade-button {
            position: absolute;
            bottom: -22px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, #8b69ff 0%, #6b4fd9 100%);
            border: 1px solid #5a3fb8;
            border-radius: 3px;
            padding: 3px 8px;
            font-size: 10px;
            font-weight: 600;
            color: #fff;
            cursor: pointer;
            white-space: nowrap;
            z-index: 20;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
        }
        
        .trade-button:hover {
            background: linear-gradient(135deg, #9b79ff 0%, #7b5fe9 100%);
            transform: translateX(-50%) scale(1.05);
            box-shadow: 0 4px 12px rgba(139, 105, 255, 0.5);
        }
        
        .trade-button:active {
            transform: translateX(-50%) scale(0.95);
        }
        
        .trade-button:disabled {
            opacity: 0.4;
            cursor: not-allowed;
            background: linear-gradient(135deg, #555 0%, #444 100%);
            border-color: #333;
        }
        
        .trade-button:disabled:hover {
            transform: translateX(-50%);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
        }
        
        .trade-button[title]:hover::after {
            content: attr(title);
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.95);
            color: #f0e6d2;
            padding: 6px 10px;
            border-radius: 4px;
            font-size: 10px;
            white-space: nowrap;
            margin-bottom: 4px;
            z-index: 1000;
            pointer-events: none;
            border: 1px solid rgba(200, 170, 110, 0.3);
        }
        
        .trade-button[title]:hover::before {
            content: '';
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            border: 4px solid transparent;
            border-top-color: rgba(0, 0, 0, 0.95);
            margin-bottom: -4px;
            z-index: 1000;
            pointer-events: none;
        }
        
        /* Queue Control Panel */
        .queue-control-panel {
            background: linear-gradient(135deg, rgba(1, 10, 19, 0.95) 0%, rgba(5, 15, 25, 0.95) 100%);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
        }
        
        .queue-control-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid rgba(200, 170, 110, 0.2);
        }
        
        .queue-control-icon {
            font-size: 24px;
        }
        
        .queue-control-title {
            font-size: 18px;
            font-weight: 700;
            color: #c8aa6e;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .queue-selector {
            display: grid;
            grid-template-columns: 1fr;
            gap: 8px;
            margin-bottom: 16px;
        }
        
        .queue-option {
            display: block;
            cursor: pointer;
            position: relative;
        }
        
        .queue-option input[type="radio"] {
            position: absolute;
            opacity: 0;
        }
        
        .queue-option-content {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            background: rgba(0, 0, 0, 0.3);
            border: 2px solid rgba(200, 170, 110, 0.2);
            border-radius: 8px;
            transition: all 0.2s ease;
        }
        
        .queue-option:hover .queue-option-content {
            border-color: rgba(200, 170, 110, 0.5);
            background: rgba(200, 170, 110, 0.05);
        }
        
        .queue-option input[type="radio"]:checked + .queue-option-content {
            border-color: #0ac8b9;
            background: rgba(10, 200, 185, 0.1);
            box-shadow: 0 0 12px rgba(10, 200, 185, 0.3);
        }
        
        .queue-option-icon {
            font-size: 24px;
            min-width: 32px;
            text-align: center;
        }
        
        .queue-option-text {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        
        .queue-option-text strong {
            color: #f0e6d2;
            font-size: 14px;
        }
        
        .queue-option-text small {
            color: #a09b8c;
            font-size: 11px;
        }
        
        .queue-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 16px;
        }
        
        .queue-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 14px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid;
        }
        
        .queue-btn-icon {
            font-size: 16px;
        }
        
        .queue-btn-start {
            background: linear-gradient(135deg, #0ac8b9 0%, #0397ab 100%);
            border-color: #026b7a;
            color: #fff;
        }
        
        .queue-btn-start:hover:not(:disabled) {
            background: linear-gradient(135deg, #0de9d7 0%, #04b7c9 100%);
            box-shadow: 0 4px 16px rgba(10, 200, 185, 0.4);
            transform: translateY(-2px);
        }
        
        .queue-btn-stop {
            background: linear-gradient(135deg, #e84057 0%, #c41e3a 100%);
            border-color: #8b1a2e;
            color: #fff;
        }
        
        .queue-btn-stop:hover:not(:disabled) {
            background: linear-gradient(135deg, #ff4d6a 0%, #d42847 100%);
            box-shadow: 0 4px 16px rgba(232, 64, 87, 0.4);
            transform: translateY(-2px);
        }
        
        .queue-btn:active:not(:disabled) {
            transform: translateY(0);
        }
        
        .queue-btn:disabled {
            opacity: 0.4;
            cursor: not-allowed;
            transform: none !important;
        }
        
        .queue-status {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 16px;
            background: rgba(10, 200, 185, 0.1);
            border: 2px solid rgba(10, 200, 185, 0.3);
            border-radius: 8px;
            animation: pulse 2s infinite;
        }
        
        .queue-status.hidden {
            display: none;
        }
        
        .queue-status-icon {
            font-size: 24px;
            animation: spin 2s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .queue-status-text {
            font-size: 14px;
            font-weight: 600;
            color: #0ac8b9;
        }
        
        @media (max-width: 480px) {
            .queue-control-panel {
                padding: 16px;
            }
            
            .queue-actions {
                grid-template-columns: 1fr;
            }
            
            .queue-option-content {
                padding: 10px 12px;
            }
        }
        
        /* Trade Modal */
        .trade-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.9);
            z-index: 10000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .trade-modal.active {
            display: flex;
        }
        
        .trade-modal-content {
            background: linear-gradient(135deg, #0a1428 0%, #1b2838 100%);
            border: 2px solid rgba(200, 170, 110, 0.4);
            border-radius: 12px;
            padding: 24px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.8);
        }
        
        .trade-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .trade-modal-title {
            font-size: 18px;
            font-weight: 700;
            color: #c8aa6e;
        }
        
        .trade-modal-close {
            background: none;
            border: none;
            color: #a09b8c;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            transition: all 0.2s ease;
        }
        
        .trade-modal-close:hover {
            background: rgba(200, 170, 110, 0.1);
            color: #c8aa6e;
        }
        
        .trade-type-selector {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 20px;
        }
        
        .trade-type-option {
            background: rgba(0, 0, 0, 0.4);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 8px;
            padding: 16px;
            cursor: pointer;
            transition: all 0.2s ease;
            text-align: center;
        }
        
        .trade-type-option:hover {
            border-color: rgba(200, 170, 110, 0.6);
            background: rgba(200, 170, 110, 0.1);
        }
        
        .trade-type-option.selected {
            border-color: #0ac8b9;
            background: rgba(10, 200, 185, 0.1);
        }
        
        .trade-type-option.disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }
        
        .trade-type-option.disabled:hover {
            border-color: rgba(200, 170, 110, 0.3);
            background: rgba(0, 0, 0, 0.4);
        }
        
        .trade-type-icon {
            font-size: 32px;
            margin-bottom: 8px;
        }
        
        .trade-type-label {
            font-size: 14px;
            font-weight: 600;
            color: #f0e6d2;
            margin-bottom: 4px;
        }
        
        .trade-type-desc {
            font-size: 11px;
            color: #a09b8c;
        }
        
        .trade-preview {
            background: rgba(0, 0, 0, 0.4);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
        }
        
        .trade-preview-title {
            font-size: 12px;
            color: #a09b8c;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .trade-preview-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            font-size: 14px;
            color: #f0e6d2;
        }
        
        .trade-preview-arrow {
            font-size: 20px;
            color: #c8aa6e;
        }
        
        .trade-modal-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        
        .trade-modal-btn {
            padding: 12px 20px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid;
        }
        
        .trade-modal-btn-confirm {
            background: linear-gradient(135deg, #0ac8b9 0%, #0397ab 100%);
            border-color: #026b7a;
            color: #fff;
        }
        
        .trade-modal-btn-confirm:hover {
            background: linear-gradient(135deg, #0de9d7 0%, #04b7c9 100%);
            box-shadow: 0 4px 12px rgba(10, 200, 185, 0.4);
        }
        
        .trade-modal-btn-cancel {
            background: rgba(0, 0, 0, 0.4);
            border-color: rgba(200, 170, 110, 0.3);
            color: #f0e6d2;
        }
        
        .trade-modal-btn-cancel:hover {
            background: rgba(200, 170, 110, 0.1);
            border-color: rgba(200, 170, 110, 0.6);
        }
        
        .trade-modal-btn:active {
            transform: scale(0.95);
        }
        
        .trade-modal-btn:disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }
        
        /* Banned Champion Display */
        .banned-champion {
            position: relative;
            width: 36px;
            height: 36px;
            border-radius: 4px;
            overflow: hidden;
            border: 2px solid #e84057;
            background: rgba(0, 0, 0, 0.6);
            opacity: 0.7;
            filter: grayscale(100%);
        }
        
        .banned-champion img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .banned-champion::after {
            content: '🚫';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 16px;
            text-shadow: 0 0 4px rgba(0, 0, 0, 0.8);
        }
        
        @media (max-width: 480px) {
            .team-member, .team-member-placeholder {
                width: 44px;
                height: 44px;
            }
            
            .banned-champion {
                width: 32px;
                height: 32px;
            }
            
            .banned-champion::after {
                font-size: 14px;
            }
        }
        
        /* QR Scanner Modal */
        .qr-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.95);
            z-index: 9999;
            padding: 20px;
            overflow-y: auto;
        }
        
        .qr-modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .qr-modal-content {
            background: linear-gradient(135deg, #0a1428 0%, #1b2838 100%);
            border: 2px solid rgba(200, 170, 110, 0.3);
            border-radius: 16px;
            padding: 24px;
            max-width: 500px;
            width: 100%;
            position: relative;
        }
        
        .qr-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .qr-modal-title {
            font-size: 20px;
            font-weight: 700;
            color: #c8aa6e;
        }
        
        .qr-modal-close {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: #f0e6d2;
            width: 32px;
            height: 32px;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        
        .qr-modal-close:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        #qr-reader {
            border-radius: 12px;
            overflow: hidden;
            border: 2px solid rgba(200, 170, 110, 0.3);
        }
        
        #qr-reader video {
            border-radius: 12px;
        }
        
        .qr-status {
            margin-top: 16px;
            padding: 12px;
            border-radius: 8px;
            text-align: center;
            font-size: 14px;
        }
        
        .qr-status.success {
            background: rgba(10, 200, 185, 0.2);
            color: #0ac8b9;
            border: 1px solid rgba(10, 200, 185, 0.3);
        }
        
        .qr-status.error {
            background: rgba(255, 77, 77, 0.2);
            color: #ff4d4d;
            border: 1px solid rgba(255, 77, 77, 0.3);
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Autrex Logo -->
        <div class="autrex-logo">
            <div class="autrex-logo-text">AUTREX 
                (Suitable for ranked game modes)
            </div>
            <span class="autrex-badge">Remote Control</span>
        </div>
        
        <?php if (!$sessionCode): ?>
            <!-- Session Code Input -->
            <div class="session-input-container">
                <div class="session-hero">
                    <div class="session-hero-icon">📱</div>
                    <h1 class="session-hero-title">Remote Control</h1>
                    <p class="session-hero-subtitle">Enter your 6-digit session code from the Autrex desktop app</p>
                </div>
                
                <?php if (isset($error)): ?>
                    <div class="error-message mb-4" style="max-width: 400px; margin: 0 auto 20px;">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="GET" action="" id="codeForm">
                    <!-- Hidden input for form submission -->
                    <input type="hidden" name="code" id="codeInput" value="">
                    
                    <!-- Visual code input boxes -->
                    <div class="code-input-wrapper">
                        <input type="text" class="code-input-box" maxlength="1" data-index="0" autocomplete="off">
                        <input type="text" class="code-input-box" maxlength="1" data-index="1" autocomplete="off">
                        <input type="text" class="code-input-box" maxlength="1" data-index="2" autocomplete="off">
                        <input type="text" class="code-input-box" maxlength="1" data-index="3" autocomplete="off">
                        <input type="text" class="code-input-box" maxlength="1" data-index="4" autocomplete="off">
                        <input type="text" class="code-input-box" maxlength="1" data-index="5" autocomplete="off">
                    </div>
                    
                    <button 
                        type="submit"
                        class="lol-button"
                        id="connectBtn"
                        disabled
                        style="opacity: 0.5; cursor: not-allowed;"
                    >
                        Connect
                    </button>
                </form>
                
                <!-- QR Scanner Button -->
                <div style="margin-top: 20px; text-align: center;">
                    <button 
                        type="button"
                        onclick="openQRScanner()"
                        class="lol-button"
                        style="background: linear-gradient(135deg, #8b45ff 0%, #6b35cc 100%); display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px;"
                    >
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="3" width="7" height="7"></rect>
                            <rect x="14" y="3" width="7" height="7"></rect>
                            <rect x="14" y="14" width="7" height="7"></rect>
                            <rect x="3" y="14" width="7" height="7"></rect>
                        </svg>
                        Scan QR Code
                    </button>
                </div>
                
                <div style="margin-top: 32px; text-align: center; color: #5b5a56; font-size: 14px; line-height: 1.8; max-width: 400px;">
                    <p style="margin-bottom: 12px;">
                        <span style="display: inline-block; padding: 4px 12px; background: rgba(139, 69, 255, 0.2); border-radius: 8px; color: #8b45ff; font-weight: 600;">💡 How to get your code</span>
                    </p>
                    <p>Open <strong style="color: #c8aa6e;">Autrex</strong> desktop app → Enable <strong style="color: #c8aa6e;">Remote Control</strong> → Copy your session code</p>
                </div>
            </div>
            
            <script>
                // Code input handling
                const codeBoxes = document.querySelectorAll('.code-input-box');
                const codeInput = document.getElementById('codeInput');
                const connectBtn = document.getElementById('connectBtn');
                const codeForm = document.getElementById('codeForm');
                
                codeBoxes.forEach((box, index) => {
                    // Auto-focus first box
                    if (index === 0) {
                        box.focus();
                    }
                    
                    box.addEventListener('input', (e) => {
                        const value = e.target.value.toUpperCase();
                        e.target.value = value;
                        
                        // Add filled class
                        if (value) {
                            e.target.classList.add('filled');
                        } else {
                            e.target.classList.remove('filled');
                        }
                        
                        // Move to next box
                        if (value && index < codeBoxes.length - 1) {
                            codeBoxes[index + 1].focus();
                        }
                        
                        // Update hidden input and check if complete
                        updateCode();
                    });
                    
                    box.addEventListener('keydown', (e) => {
                        // Backspace: move to previous box
                        if (e.key === 'Backspace' && !e.target.value && index > 0) {
                            codeBoxes[index - 1].focus();
                        }
                        
                        // Arrow keys navigation
                        if (e.key === 'ArrowLeft' && index > 0) {
                            codeBoxes[index - 1].focus();
                        }
                        if (e.key === 'ArrowRight' && index < codeBoxes.length - 1) {
                            codeBoxes[index + 1].focus();
                        }
                    });
                    
                    // Paste handling
                    box.addEventListener('paste', (e) => {
                        e.preventDefault();
                        const pastedData = e.clipboardData.getData('text').toUpperCase().slice(0, 6);
                        
                        pastedData.split('').forEach((char, i) => {
                            if (codeBoxes[i]) {
                                codeBoxes[i].value = char;
                                codeBoxes[i].classList.add('filled');
                            }
                        });
                        
                        // Focus last filled box or next empty
                        const lastIndex = Math.min(pastedData.length, codeBoxes.length - 1);
                        codeBoxes[lastIndex].focus();
                        
                        updateCode();
                    });
                });
                
                function updateCode() {
                    const code = Array.from(codeBoxes).map(box => box.value).join('');
                    codeInput.value = code;
                    
                    // Enable/disable connect button
                    if (code.length === 6) {
                        connectBtn.disabled = false;
                        connectBtn.style.opacity = '1';
                        connectBtn.style.cursor = 'pointer';
                    } else {
                        connectBtn.disabled = true;
                        connectBtn.style.opacity = '0.5';
                        connectBtn.style.cursor = 'not-allowed';
                    }
                }
                
                // Auto-submit on complete
                codeForm.addEventListener('submit', (e) => {
                    if (codeInput.value.length !== 6) {
                        e.preventDefault();
                    }
                });
            </script>
        <?php else: ?>

            <!-- Remote Control Interface -->
            <div id="remoteControl" class="space-y-4">
                <!-- Compact Header with Session & Status -->
                <div class="lol-card">
                    <div class="p-6">
                        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;">
                            <div style="flex: 1; min-width: 0;">
                                <div style="font-size: 10px; color: #a09b8c; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px;">Session</div>
                                <div style="font-family: 'Courier New', monospace; font-size: 20px; font-weight: 700; letter-spacing: 3px; color: #c8aa6e;">
                                    <?php echo $sessionCode; ?>
                                </div>
                            </div>
                            <div id="connectionStatus" class="status-badge">
                                <div class="status-dot disconnected"></div>
                                <span>Connecting...</span>
                            </div>
                        </div>
                        
                        <!-- Account Info (Inline) -->
                        <div id="accountInfo" class="hidden" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid rgba(200, 170, 110, 0.2);">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="position: relative;">
                                    <div id="accountIconContainer" style="width: 48px; height: 48px; border-radius: 50%; overflow: hidden; border: 2px solid #0ac8b9; box-shadow: 0 0 12px rgba(10, 200, 185, 0.4);">
                                        <img id="accountIcon" src="" alt="Profile" style="width: 100%; height: 100%; object-fit: cover;">
                                    </div>
                                    <!-- Rank Badge -->
                                    <div id="rankBadge" class="hidden" style="position: absolute; bottom: -6px; right: -6px; width: 32px; height: 32px; border-radius: 50%; border: 2px solid #0a1428; background: linear-gradient(135deg, #1a1a2e 0%, #0f0f1e 100%); overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.8);">
                                        <img id="rankIcon" src="" alt="Rank" style="width: 100%; height: 100%; object-fit: cover;">
                                    </div>
                                </div>
                                <div style="flex: 1; min-width: 0;">
                                    <div style="font-size: 10px; color: #a09b8c; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 2px;">Connected Account</div>
                                    <div id="accountName" style="font-size: 14px; font-weight: 700; color: #0ac8b9; margin-bottom: 2px;">Loading...</div>
                                    <div id="accountLevel" style="font-size: 11px; color: #a09b8c;">Level: --</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Game Status (Inline) -->
                        <div id="gameStatusInline" class="hidden" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid rgba(200, 170, 110, 0.2);">
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div id="gameStatusIcon" style="font-size: 28px;">⏳</div>
                                <div style="flex: 1; min-width: 0;">
                                    <div id="gameStatusTitle" style="font-size: 14px; font-weight: 700; color: #c8aa6e; margin-bottom: 2px;">Waiting...</div>
                                    <div id="gameStatusSubtitle" style="font-size: 11px; color: #a09b8c;">Connecting to game client</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Your Position Display -->
                <div id="yourPosition" class="hidden lol-card" style="margin-bottom: 12px;">
                    <div style="padding: 12px; display: flex; align-items: center; gap: 12px; background: linear-gradient(135deg, rgba(200, 170, 110, 0.15) 0%, rgba(139, 69, 255, 0.15) 100%);">
                        <div id="yourPositionIcon" style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; background: rgba(0, 0, 0, 0.4); border-radius: 8px; border: 2px solid rgba(200, 170, 110, 0.5);">
                            <!-- Position icon will be inserted here -->
                        </div>
                        <div style="flex: 1; min-width: 0;">
                            <div style="font-size: 10px; color: #a09b8c; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Your Role</div>
                            <div id="yourPositionText" style="font-size: 16px; font-weight: 700; color: #c8aa6e; text-transform: capitalize;">Loading...</div>
                        </div>
                    </div>
                </div>
                
                <!-- Turn Info (Compact Mobile) -->
                <div id="turnInfo" class="hidden lol-card" style="margin-bottom: 12px;">
                    <div style="padding: 12px; display: flex; align-items: center; justify-content: space-between; gap: 12px;">
                        <div style="flex: 1; min-width: 0;">
                            <div id="currentPhaseText" style="font-size: 11px; color: #a09b8c; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">Phase</div>
                            <div id="currentActionText" style="font-size: 13px; font-weight: 700; color: #c8aa6e;">Waiting...</div>
                        </div>
                        <div id="turnIndicator" style="text-align: right;">
                            <div style="font-size: 32px; line-height: 1;">⏳</div>
                        </div>
                    </div>
                </div>
                
                <!-- Teams & Bans (Compact Mobile) -->
                <div id="teamsDisplay" class="hidden lol-card" style="margin-bottom: 12px;">
                    <div style="padding: 12px;">
                        <!-- My Team -->
                        <div style="margin-bottom: 12px;">
                            <div style="font-size: 10px; color: #0ac8b9; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; font-weight: 700;">🟢 Your Team</div>
                            <div id="myTeamDisplay" style="display: flex; gap: 6px; flex-wrap: wrap;">
                                <!-- Team members will be added here -->
                            </div>
                        </div>
                        
                        <!-- Enemy Team -->
                        <div style="margin-bottom: 12px;">
                            <div style="font-size: 10px; color: #e84057; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; font-weight: 700;">🔴 Enemy Team</div>
                            <div id="enemyTeamDisplay" style="display: flex; gap: 6px; flex-wrap: wrap;">
                                <!-- Enemy members will be added here -->
                            </div>
                        </div>
                        
                        <!-- Bans -->
                        <div id="bansSection" class="hidden">
                            <div style="font-size: 10px; color: #a09b8c; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; font-weight: 700;">🚫 Banned Champions</div>
                            <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                <div id="myTeamBans" style="display: flex; gap: 4px; flex-wrap: wrap;">
                                    <!-- My team bans -->
                                </div>
                                <div style="width: 1px; background: rgba(200, 170, 110, 0.2); margin: 0 4px;"></div>
                                <div id="enemyTeamBans" style="display: flex; gap: 4px; flex-wrap: wrap;">
                                    <!-- Enemy team bans -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Current Action Display (Auto-determined, No Manual Tabs) -->
                <div id="currentActionDisplay" class="hidden lol-card" style="margin-bottom: 12px;">
                    <div style="padding: 12px; text-align: center;">
                        <div id="actionModeIcon" style="font-size: 32px; margin-bottom: 8px;">✅</div>
                        <div id="actionModeText" style="font-size: 14px; font-weight: 700; color: #c8aa6e; text-transform: uppercase; letter-spacing: 1px;">Pick Mode</div>
                        <div id="actionModeBadge" style="font-size: 10px; color: #a09b8c; margin-top: 4px;">Owned Champions Only</div>
                    </div>
                </div>
                
                <!-- Lobby Members (Premades) -->
                <div id="lobbyMembers" class="lol-card hidden" style="margin-bottom: 16px;">
                    <div class="lol-header" style="padding: 16px;">
                        <div style="font-size: 18px; font-weight: 700; color: #c8aa6e; text-transform: uppercase; letter-spacing: 1px;">
                            👥 Lobby Members
                        </div>
                    </div>
                    <div class="p-6" style="padding: 16px;">
                        <div id="lobbyMembersList" style="display: flex; flex-direction: column; gap: 8px;">
                            <!-- Members will be rendered here -->
                        </div>
                        
                        <!-- Position Selection (for ranked queues) -->
                        <div id="positionSelection" class="hidden" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid rgba(200, 170, 110, 0.2);">
                            <div style="font-size: 14px; font-weight: 700; color: #c8aa6e; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 1px;">
                                🎯 Select Your Positions
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                                <div>
                                    <label style="font-size: 11px; color: #a09b8c; display: block; margin-bottom: 4px;">Primary</label>
                                    <select id="primaryPosition" class="position-select" onchange="updatePositionPreferences()">
                                        <option value="">Select...</option>
                                        <option value="top">🛡️ Top</option>
                                        <option value="jungle">🌲 Jungle</option>
                                        <option value="middle">⚡ Mid</option>
                                        <option value="bottom">🏹 ADC</option>
                                        <option value="utility">💚 Support</option>
                                        <option value="fill">🎲 Fill</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="font-size: 11px; color: #a09b8c; display: block; margin-bottom: 4px;">Secondary</label>
                                    <select id="secondaryPosition" class="position-select" onchange="updatePositionPreferences()">
                                        <option value="">Select...</option>
                                        <option value="top">🛡️ Top</option>
                                        <option value="jungle">🌲 Jungle</option>
                                        <option value="middle">⚡ Mid</option>
                                        <option value="bottom">🏹 ADC</option>
                                        <option value="utility">💚 Support</option>
                                        <option value="fill">🎲 Fill</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Queue Control -->
                <div id="queueControl" class="queue-control-panel">
                    <div class="queue-control-header">
                        <span class="queue-control-icon">🎮</span>
                        <span class="queue-control-title">Queue Control</span>
                    </div>
                    
                    <div class="queue-control-body">
                        <div class="queue-selector">
                            <label class="queue-option">
                                <input type="radio" name="queueType" value="420" checked>
                                <span class="queue-option-content">
                                    <span class="queue-option-icon">👑</span>
                                    <span class="queue-option-text">
                                        <strong>Ranked Solo/Duo</strong>
                                        <small>Competitive 5v5</small>
                                    </span>
                                </span>
                            </label>
                            
                            <label class="queue-option">
                                <input type="radio" name="queueType" value="440">
                                <span class="queue-option-content">
                                    <span class="queue-option-icon">👥</span>
                                    <span class="queue-option-text">
                                        <strong>Ranked Flex</strong>
                                        <small>Team Ranked 5v5</small>
                                    </span>
                                </span>
                            </label>
                            
                            <label class="queue-option">
                                <input type="radio" name="queueType" value="400">
                                <span class="queue-option-content">
                                    <span class="queue-option-icon">⚔️</span>
                                    <span class="queue-option-text">
                                        <strong>Normal Draft</strong>
                                        <small>Casual 5v5 Draft</small>
                                    </span>
                                </span>
                            </label>
                            
                            <label class="queue-option">
                                <input type="radio" name="queueType" value="430">
                                <span class="queue-option-content">
                                    <span class="queue-option-icon">🎯</span>
                                    <span class="queue-option-text">
                                        <strong>Normal Blind</strong>
                                        <small>Casual 5v5 Blind</small>
                                    </span>
                                </span>
                            </label>
                            
                            <label class="queue-option">
                                <input type="radio" name="queueType" value="450">
                                <span class="queue-option-content">
                                    <span class="queue-option-icon">🌉</span>
                                    <span class="queue-option-text">
                                        <strong>ARAM</strong>
                                        <small>All Random All Mid</small>
                                    </span>
                                </span>
                            </label>
                        </div>
                        
                        <div class="queue-actions">
                            <button id="startQueueBtn" class="queue-btn queue-btn-start" onclick="startQueue()">
                                <span class="queue-btn-icon">▶️</span>
                                <span>Start Queue</span>
                            </button>
                            <button id="stopQueueBtn" class="queue-btn queue-btn-stop" onclick="stopQueue()" disabled>
                                <span class="queue-btn-icon">⏹️</span>
                                <span>Stop Queue</span>
                            </button>
                        </div>
                        
                        <div id="queueStatus" class="queue-status hidden">
                            <div class="queue-status-icon">⏳</div>
                            <div class="queue-status-text">Searching for match...</div>
                        </div>
                    </div>
                </div>
                
                <!-- Champion Select (Full Width, No Card) -->
                <div id="championSelect" class="hidden" style="position: relative;">
                    <!-- Search Bar -->
                    <div style="margin-bottom: 12px;">
                        <input 
                            type="text" 
                            id="championSearch"
                            placeholder="🔍 Search champion..."
                            autocomplete="off"
                            onkeydown="if(event.key === 'Enter') event.preventDefault();"
                        >
                    </div>
                    
                    <!-- Champion Count -->
                    <div id="championCount" style="font-size: 11px; color: #a09b8c; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; text-align: center;">
                        Loading champions...
                    </div>
                    
                    <!-- Champion Grid Container -->
                    <div style="position: relative;">
                        <!-- Champion Grid -->
                        <div id="championGrid" class="champion-grid">
                            <!-- Champions will be loaded here -->
                        </div>
                        
                        <!-- Waiting Overlay - REMOVED, using opacity instead -->
                    </div>
                </div>
                
                <!-- Fixed Bottom Action Button -->
                <div id="actionButtonContainer" class="hidden" style="position: fixed; bottom: 0; left: 0; right: 0; padding: 12px 16px; background: linear-gradient(180deg, transparent 0%, #0a1428 20%, #0a1428 100%); z-index: 20; box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.5);">
                    <button 
                        id="actionBtn"
                        class="action-button pick"
                        disabled
                        onclick="sendCommand()"
                    >
                        <span id="actionBtnText">✅ Pick Champion</span>
                    </button>
                    
                    <!-- Selected Champion Info -->
                    <div id="selectedChampionInfo" class="hidden" style="text-align: center; margin-top: 8px; font-size: 12px; color: #a09b8c;">
                        <span id="selectedChampionName"></span>
                    </div>
                </div>
                
                <!-- Messages (Toast Style) -->
                <div id="errorMessage" class="error-message hidden" style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); max-width: 90%; z-index: 100; animation: slideDown 0.3s ease;"></div>
                <div id="successMessage" class="success-message hidden" style="position: fixed; top: 20px; left: 50%; transform: translateX(-50%); max-width: 90%; z-index: 100; animation: slideDown 0.3s ease;"></div>
                
                <!-- Your Turn Overlay -->
                <div id="yourTurnOverlay" class="your-turn-overlay">
                    <div class="your-turn-content">
                        <div class="your-turn-pulse">
                            <span id="yourTurnIcon">⏳</span>
                        </div>
                        <h2 class="your-turn-title">YOUR TURN!</h2>
                        <p class="your-turn-subtitle" id="yourTurnSubtitle">Pick your champion now</p>
                        <div class="your-turn-timer" id="yourTurnTimer">30s</div>
                        <button class="your-turn-dismiss" onclick="dismissYourTurn()">
                            Got it! Let me pick
                        </button>
                    </div>
                </div>
                
                <!-- Trade Notifications -->
                <div id="tradeNotifications" class="trade-notifications">
                    <!-- Trade requests will be dynamically added here -->
                </div>
                
                <!-- Trade Initiation Modal -->
                <div id="tradeModal" class="trade-modal">
                    <div class="trade-modal-content">
                        <div class="trade-modal-header">
                            <div class="trade-modal-title">Request Trade</div>
                            <button class="trade-modal-close" onclick="closeTradeModal()">×</button>
                        </div>
                        
                        <div class="trade-type-selector">
                            <div class="trade-type-option" id="tradeTypePickOrder" onclick="selectTradeType('PICK_ORDER')">
                                <div class="trade-type-icon">🔄</div>
                                <div class="trade-type-label">Pick Order</div>
                                <div class="trade-type-desc">Swap pick positions</div>
                            </div>
                            <div class="trade-type-option" id="tradeTypeChampion" onclick="selectTradeType('CHAMPION')">
                                <div class="trade-type-icon">⚔️</div>
                                <div class="trade-type-label">Champion</div>
                                <div class="trade-type-desc">Swap champions</div>
                            </div>
                        </div>
                        
                        <div class="trade-preview">
                            <div class="trade-preview-title">Trade Preview</div>
                            <div class="trade-preview-content" id="tradePreviewContent">
                                Select a trade type
                            </div>
                        </div>
                        
                        <div class="trade-modal-actions">
                            <button class="trade-modal-btn trade-modal-btn-cancel" onclick="closeTradeModal()">Cancel</button>
                            <button class="trade-modal-btn trade-modal-btn-confirm" id="confirmTradeBtn" onclick="confirmTrade()" disabled>Send Request</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <style>
                @keyframes slideDown {
                    from {
                        opacity: 0;
                        transform: translateX(-50%) translateY(-20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateX(-50%) translateY(0);
                    }
                }
                
                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: scale(0.8);
                    }
                    to {
                        opacity: 1;
                        transform: scale(1);
                    }
                }
                
                /* Add padding to bottom for fixed button */
                #championSelect {
                    padding-bottom: 100px;
                }
            </style>
            
            <script>
                const SESSION_CODE = '<?php echo $sessionCode; ?>';
                const SUPABASE_URL = '<?php echo SUPABASE_URL; ?>';
                const SUPABASE_ANON_KEY = '<?php echo SUPABASE_ANON_KEY; ?>';
                
                // Initialize Supabase client
                const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
                
                let selectedChampion = null;
                let currentState = null;
                let currentMode = 'pick'; // 'pick' or 'ban' - auto-determined, no manual switching
                let champions = [];
                let ownedChampionIds = [];
                let isMyTurnGlobal = false; // Track if it's currently the player's turn
                
                // Initialize
                async function init() {
                    try {
                        // Verify session exists
                        const { data: session, error } = await supabaseClient
                            .from('remote_sessions')
                            .select('*')
                            .eq('session_code', SESSION_CODE)
                            .eq('is_active', true)
                            .single();
                        
                        if (error || !session) {
                            showError('Session not found or expired. Please check your code.');
                            return;
                        }
                        
                        updateConnectionStatus('connected');
                        
                        // Load champions
                        await loadChampions();
                        
                        // Subscribe to state updates
                        subscribeToState();
                        subscribeToGameStatus();
                        subscribeToTrades();
                        subscribeToLobbyState();
                        
                        // Setup UI
                        setupUI();
                        
                        // Fetch initial game status immediately
                        await fetchGameStatus();
                        
                        // Fetch initial lobby state immediately
                        await fetchLobbyState();
                        
                        // Poll for state updates frequently for real-time sync
                        setInterval(pollState, 500); // Poll every 500ms for near real-time updates
                        
                        // Poll for game status updates (to get summoner info)
                        setInterval(fetchGameStatus, 2000); // Poll every 2 seconds for game status
                        
                        // Poll for lobby state updates
                        setInterval(fetchLobbyState, 2000); // Poll every 2 seconds for lobby state
                        
                    } catch (error) {
                        console.error('Init error:', error);
                        showError('Failed to connect: ' + error.message);
                    }
                }
                
                // Load champion data - Get latest version dynamically
                async function loadChampions() {
                    try {
                        console.log('📥 Loading champion data from Data Dragon...');
                        
                        // Get latest version
                        const versionsResponse = await fetch('https://ddragon.leagueoflegends.com/api/versions.json');
                        const versions = await versionsResponse.json();
                        const latestVersion = versions[0];
                        console.log('📦 Latest Data Dragon version:', latestVersion);
                        
                        // Load champions with latest version
                        const response = await fetch(`https://ddragon.leagueoflegends.com/cdn/${latestVersion}/data/en_US/champion.json`);
                        const data = await response.json();
                        champions = Object.values(data.data);
                        
                        // Store version for image URLs
                        window.DD_VERSION = latestVersion;
                        
                        console.log('✅ Loaded', champions.length, 'champions');
                        console.log('🔍 Checking for new champions:', {
                            hasAurora: champions.some(c => c.name === 'Aurora'),
                            hasAmbessa: champions.some(c => c.name === 'Ambessa'),
                            hasMel: champions.some(c => c.name === 'Mel')
                        });
                        
                        // If we're already in champion select, render now
                        const championSelect = document.getElementById('championSelect');
                        if (championSelect && !championSelect.classList.contains('hidden')) {
                            console.log('🎨 Champion select is visible, rendering champions now');
                            renderChampions();
                        }
                    } catch (error) {
                        console.error('❌ Failed to load champions:', error);
                        showError('Failed to load champion data');
                        // Fallback to hardcoded version
                        window.DD_VERSION = '15.1.1';
                    }
                }
                
                // Switch between pick and ban modes (AUTOMATIC ONLY - based on game phase)
                function switchMode(mode) {
                    if (currentMode === mode) return; // Already in this mode
                    
                    currentMode = mode;
                    console.log('🔄 Auto-switched to mode:', mode);
                    
                    // Update action display
                    const actionModeIcon = document.getElementById('actionModeIcon');
                    const actionModeText = document.getElementById('actionModeText');
                    const actionModeBadge = document.getElementById('actionModeBadge');
                    
                    if (mode === 'pick') {
                        actionModeIcon.textContent = '✅';
                        actionModeText.textContent = 'Pick Phase';
                        actionModeText.style.color = '#0ac8b9';
                        actionModeBadge.textContent = 'Owned Champions Only';
                    } else {
                        actionModeIcon.textContent = '🚫';
                        actionModeText.textContent = 'Ban Phase';
                        actionModeText.style.color = '#e84057';
                        actionModeBadge.textContent = 'All Champions';
                    }
                    
                    // Update button
                    const btn = document.getElementById('actionBtn');
                    const btnText = document.getElementById('actionBtnText');
                    const selectedInfo = document.getElementById('selectedChampionInfo');
                    
                    if (mode === 'pick') {
                        btn.className = 'action-button pick';
                        btnText.textContent = '✅ Pick Champion';
                    } else {
                        btn.className = 'action-button ban';
                        btnText.textContent = '🚫 Ban Champion';
                    }
                    
                    // Re-render champions with filter
                    renderChampions();
                    
                    // Clear selection when mode changes
                    selectedChampion = null;
                    btn.disabled = true;
                    selectedInfo.classList.add('hidden');
                    
                    // DON'T clear search - let user keep their search term
                }

                
                // Render champion grid with filtering
                function renderChampions(filter) {
                    const grid = document.getElementById('championGrid');
                    const countEl = document.getElementById('championCount');
                    const searchInput = document.getElementById('championSearch');
                    
                    // If no filter provided, use current search input value
                    if (filter === undefined && searchInput) {
                        filter = searchInput.value;
                    }
                    
                    // Get banned and picked champion IDs from current state
                    const bannedChampionIds = new Set();
                    const pickedChampionIds = new Set();
                    
                    if (currentState && currentState.actions) {
                        currentState.actions.flat().forEach(action => {
                            if (action.completed && action.championId > 0) {
                                if (action.type === 'ban') {
                                    bannedChampionIds.add(action.championId);
                                } else if (action.type === 'pick') {
                                    pickedChampionIds.add(action.championId);
                                }
                            }
                        });
                    }
                    
                    console.log('🚫 Banned champions:', Array.from(bannedChampionIds));
                    console.log('✅ Picked champions:', Array.from(pickedChampionIds));
                    
                    // Filter by search term
                    let filtered = filter 
                        ? champions.filter(c => c.name.toLowerCase().includes(filter.toLowerCase()))
                        : champions;
                    
                    // Remove banned champions from grid (they shouldn't be selectable at all)
                    filtered = filtered.filter(c => !bannedChampionIds.has(parseInt(c.key)));
                    
                    // Filter by mode (pick = owned only, ban = all)
                    if (currentMode === 'pick' && ownedChampionIds.length > 0) {
                        filtered = filtered.filter(c => ownedChampionIds.includes(parseInt(c.key)));
                        console.log('Filtered to', filtered.length, 'owned champions');
                    }
                    
                    // Update champion count display
                    if (currentMode === 'pick') {
                        countEl.textContent = `${filtered.length} Owned Champions`;
                    } else {
                        countEl.textContent = `${filtered.length} Champions Available`;
                    }
                    
                    const ddVersion = window.DD_VERSION || '15.1.1';
                    grid.innerHTML = filtered.map(champ => {
                        const champId = parseInt(champ.key);
                        const isPicked = pickedChampionIds.has(champId);
                        const disabledClass = isPicked ? 'disabled' : '';
                        const onclickAttr = isPicked ? '' : `onclick="selectChampion(${champ.key}, '${champ.name.replace(/'/g, "\\'")}')"`;
                        
                        return `
                            <div 
                                class="champion-card ${disabledClass}" 
                                data-id="${champ.key}"
                                ${onclickAttr}
                                title="${champ.name}${isPicked ? ' (Already Picked)' : ''}"
                            >
                                <img 
                                    src="https://ddragon.leagueoflegends.com/cdn/${ddVersion}/img/champion/${champ.id}.png"
                                    alt="${champ.name}"
                                    loading="lazy"
                                >
                            </div>
                        `;
                    }).join('');
                    
                    if (filtered.length === 0) {
                        if (currentMode === 'pick' && ownedChampionIds.length === 0) {
                            grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #a09b8c;"><div style="font-size: 48px; margin-bottom: 16px;">⏳</div><div>Loading owned champions...</div><div style="font-size: 12px; margin-top: 8px; opacity: 0.7;">Waiting for data from desktop app</div></div>';
                            countEl.textContent = 'Loading...';
                        } else {
                            grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #a09b8c;">No champions found</div>';
                            countEl.textContent = 'No champions found';
                        }
                    }
                }
                
                // Select champion
                function selectChampion(id, name) {
                    selectedChampion = { id: parseInt(id), name };
                    
                    // Update UI
                    document.querySelectorAll('.champion-card').forEach(card => {
                        card.classList.remove('selected');
                    });
                    document.querySelector(`[data-id="${id}"]`)?.classList.add('selected');
                    
                    // Enable button and show selected champion
                    const actionBtn = document.getElementById('actionBtn');
                    const selectedInfo = document.getElementById('selectedChampionInfo');
                    const selectedName = document.getElementById('selectedChampionName');
                    
                    // Only enable button if it's the player's turn (or in ban mode where turn doesn't matter as much)
                    if (isMyTurnGlobal || currentMode === 'ban') {
                        actionBtn.disabled = false;
                    } else {
                        actionBtn.disabled = true;
                        actionBtn.title = 'Wait for your turn to pick';
                    }
                    
                    selectedInfo.classList.remove('hidden');
                    selectedName.textContent = `Selected: ${name}`;
                    
                    // Scroll to show button
                    actionBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
                
                // Send command
                async function sendCommand() {
                    if (!selectedChampion) {
                        console.warn('⚠️ No champion selected');
                        return;
                    }
                    
                    const commandType = currentMode; // 'pick' or 'ban'
                    const btn = document.getElementById('actionBtn');
                    const btnText = document.getElementById('actionBtnText');
                    const originalText = btnText.textContent;
                    
                    console.log('📤 Sending command:', {
                        type: commandType,
                        championId: selectedChampion.id,
                        championName: selectedChampion.name,
                        sessionCode: SESSION_CODE
                    });
                    
                    // Show loading state
                    btn.disabled = true;
                    btnText.textContent = '⏳ Sending...';
                    
                    try {
                        const commandData = {
                            session_code: SESSION_CODE,
                            command_type: commandType,
                            champion_id: selectedChampion.id,
                            executed: false
                        };
                        
                        console.log('📝 Inserting command into Supabase:', commandData);
                        
                        const { data, error } = await supabaseClient
                            .from('remote_commands')
                            .insert([commandData])
                            .select();
                        
                        if (error) {
                            console.error('❌ Supabase insert error:', error);
                            throw error;
                        }
                        
                        console.log('✅ Command inserted successfully:', data);
                        
                        // Show feedback
                        showSuccess(`${commandType.toUpperCase()}: ${selectedChampion.name}`);
                        
                        // Reset selection
                        selectedChampion = null;
                        document.querySelectorAll('.champion-card').forEach(card => {
                            card.classList.remove('selected');
                        });
                        document.getElementById('selectedChampionInfo').classList.add('hidden');
                        btnText.textContent = originalText;
                        
                    } catch (error) {
                        console.error('❌ Command error:', error);
                        showError('Failed to send command: ' + error.message);
                        btn.disabled = false;
                        btnText.textContent = originalText;
                    }
                }
                
                // Subscribe to champ select state
                function subscribeToState() {
                    console.log('🔔 Subscribing to champ_select_state changes...');
                    supabaseClient
                        .channel(`champ_select:${SESSION_CODE}`)
                        .on('postgres_changes', {
                            event: '*',
                            schema: 'public',
                            table: 'champ_select_state',
                            filter: `session_code=eq.${SESSION_CODE}`
                        }, (payload) => {
                            console.log('📨 Realtime state update received:', payload);
                            if (payload.new) {
                                updateState(payload.new);
                            }
                        })
                        .subscribe((status) => {
                            console.log('🔔 Subscription status:', status);
                        });
                }
                
                // Subscribe to game status
                function subscribeToGameStatus() {
                    supabaseClient
                        .channel(`game_status:${SESSION_CODE}`)
                        .on('postgres_changes', {
                            event: '*',
                            schema: 'public',
                            table: 'game_status',
                            filter: `session_code=eq.${SESSION_CODE}`
                        }, (payload) => {
                            console.log('Game status update:', payload);
                            if (payload.new) {
                                updateGameStatus(payload.new);
                            }
                        })
                        .subscribe();
                }
                
                // Subscribe to trade requests
                function subscribeToTrades() {
                    console.log('🔔 Subscribing to trade_requests...');
                    supabaseClient
                        .channel(`trades:${SESSION_CODE}`)
                        .on('postgres_changes', {
                            event: '*',
                            schema: 'public',
                            table: 'trade_requests',
                            filter: `session_code=eq.${SESSION_CODE}`
                        }, (payload) => {
                            console.log('📨 Trade update:', payload);
                            if (payload.new) {
                                handleTradeUpdate(payload.new);
                            } else if (payload.old && payload.eventType === 'DELETE') {
                                removeTradeNotification(payload.old.id);
                            }
                        })
                        .subscribe();
                }
                
                // Handle trade update
                function handleTradeUpdate(trade) {
                    console.log('🔄 Handling trade:', trade);
                    
                    if (trade.state === 'RECEIVED') {
                        // Show incoming trade notification
                        showTradeNotification(trade, 'incoming');
                    } else if (trade.state === 'SENT') {
                        // Show outgoing trade notification
                        showTradeNotification(trade, 'outgoing');
                    } else if (trade.state === 'ACCEPTED') {
                        // Update notification to show accepted status
                        updateTradeStatus(trade.id, 'accepted', `${trade.to_summoner_name} accepted!`);
                        // Remove after 3 seconds
                        setTimeout(() => removeTradeNotification(trade.id), 3000);
                    } else if (trade.state === 'DECLINED') {
                        // Update notification to show declined status
                        updateTradeStatus(trade.id, 'declined', `${trade.to_summoner_name} declined`);
                        // Remove after 3 seconds
                        setTimeout(() => removeTradeNotification(trade.id), 3000);
                    } else if (trade.state === 'EXPIRED' || trade.state === 'INVALID') {
                        // Remove notification
                        removeTradeNotification(trade.id);
                    }
                }
                
                // Show trade notification
                function showTradeNotification(trade, direction = 'incoming') {
                    const container = document.getElementById('tradeNotifications');
                    if (!container) return;
                    
                    // Check if notification already exists
                    if (document.getElementById(`trade-${trade.id}`)) {
                        return;
                    }
                    
                    const tradeCard = document.createElement('div');
                    tradeCard.id = `trade-${trade.id}`;
                    tradeCard.className = `trade-card ${direction}`;
                    
                    const tradeTypeText = trade.type === 'PICK_ORDER' ? 'Pick Order Trade' : 'Champion Trade';
                    const tradeIcon = trade.type === 'PICK_ORDER' ? '🔄' : '⚔️';
                    
                    if (direction === 'incoming') {
                        tradeCard.innerHTML = `
                            <div class="trade-header">
                                <div class="trade-icon">${tradeIcon}</div>
                                <div class="trade-title">${tradeTypeText}</div>
                            </div>
                            <div class="trade-body">
                                <span class="trade-from">${trade.from_summoner_name}</span> wants to trade with you
                            </div>
                            <div class="trade-actions">
                                <button class="trade-btn trade-btn-accept" onclick="acceptTrade(${trade.trade_id})">
                                    ✅ Accept
                                </button>
                                <button class="trade-btn trade-btn-decline" onclick="declineTrade(${trade.trade_id})">
                                    ❌ Decline
                                </button>
                            </div>
                            <div class="trade-timer" id="trade-timer-${trade.id}">30s</div>
                        `;
                    } else {
                        // Outgoing trade
                        tradeCard.innerHTML = `
                            <div class="trade-header">
                                <div class="trade-icon">⏳</div>
                                <div class="trade-title">${tradeTypeText}</div>
                            </div>
                            <div class="trade-body">
                                Waiting for <span class="trade-from">${trade.to_summoner_name}</span>...
                            </div>
                            <div class="trade-timer" id="trade-timer-${trade.id}">30s</div>
                        `;
                    }
                    
                    container.appendChild(tradeCard);
                    
                    // Start countdown timer if expires_at is available
                    if (trade.expires_at) {
                        startTradeTimer(trade.id, trade.expires_at);
                    }
                }
                
                // Update trade status
                function updateTradeStatus(tradeId, status, message) {
                    const notification = document.getElementById(`trade-${tradeId}`);
                    if (!notification) return;
                    
                    const tradeBody = notification.querySelector('.trade-body');
                    const tradeActions = notification.querySelector('.trade-actions');
                    const tradeTimer = notification.querySelector('.trade-timer');
                    
                    if (tradeBody) {
                        if (status === 'accepted') {
                            tradeBody.innerHTML = `<span style="color: #0ac8b9;">✅ ${message}</span>`;
                        } else if (status === 'declined') {
                            tradeBody.innerHTML = `<span style="color: #e84057;">❌ ${message}</span>`;
                        }
                    }
                    
                    // Remove actions and timer
                    if (tradeActions) tradeActions.remove();
                    if (tradeTimer) tradeTimer.remove();
                }
                
                // Remove trade notification
                function removeTradeNotification(tradeId) {
                    const notification = document.getElementById(`trade-${tradeId}`);
                    if (notification) {
                        notification.style.animation = 'slideOutRight 0.3s ease';
                        setTimeout(() => {
                            notification.remove();
                        }, 300);
                    }
                }
                
                // Start trade timer
                function startTradeTimer(tradeId, expiresAt) {
                    const timerEl = document.getElementById(`trade-timer-${tradeId}`);
                    if (!timerEl) return;
                    
                    const updateTimer = () => {
                        const now = new Date().getTime();
                        const expires = new Date(expiresAt).getTime();
                        const timeLeft = Math.max(0, Math.floor((expires - now) / 1000));
                        
                        if (timeLeft > 0) {
                            timerEl.textContent = `${timeLeft}s`;
                            setTimeout(updateTimer, 1000);
                        } else {
                            timerEl.textContent = 'Expired';
                            removeTradeNotification(tradeId);
                        }
                    };
                    
                    updateTimer();
                }
                
                // Accept trade
                async function acceptTrade(tradeId) {
                    try {
                        console.log('✅ Accepting trade:', tradeId);
                        
                        const { error } = await supabaseClient
                            .from('remote_commands')
                            .insert([{
                                session_code: SESSION_CODE,
                                command_type: 'accept_trade',
                                trade_id: tradeId
                            }]);
                        
                        if (error) throw error;
                        
                        showSuccess('Trade accepted!');
                    } catch (error) {
                        console.error('Failed to accept trade:', error);
                        showError('Failed to accept trade');
                    }
                }
                
                // Decline trade
                async function declineTrade(tradeId) {
                    try {
                        console.log('❌ Declining trade:', tradeId);
                        
                        const { error } = await supabaseClient
                            .from('remote_commands')
                            .insert([{
                                session_code: SESSION_CODE,
                                command_type: 'decline_trade',
                                trade_id: tradeId
                            }]);
                        
                        if (error) throw error;
                        
                        showSuccess('Trade declined');
                    } catch (error) {
                        console.error('Failed to decline trade:', error);
                        showError('Failed to decline trade');
                    }
                }
                
                // Trade initiation modal state
                let tradeModalState = {
                    targetCellId: null,
                    targetSummonerName: '',
                    selectedType: null
                };
                
                // Open trade modal
                function openTradeModal(cellId, summonerName, canTrade = true, localPlayerHasPicked = false, targetHasPicked = false) {
                    if (!canTrade) {
                        showError('Cannot trade with this player');
                        return;
                    }
                    
                    console.log('🔄 Opening trade modal for:', summonerName, 'cellId:', cellId);
                    console.log('Trade eligibility:', {
                        localPlayerHasPicked,
                        targetHasPicked,
                        canPickOrderTrade: !localPlayerHasPicked && !targetHasPicked,
                        canChampionTrade: localPlayerHasPicked && targetHasPicked
                    });
                    
                    tradeModalState.targetCellId = cellId;
                    tradeModalState.targetSummonerName = summonerName;
                    tradeModalState.selectedType = null;
                    
                    // Reset UI
                    const pickOrderOption = document.getElementById('tradeTypePickOrder');
                    const championOption = document.getElementById('tradeTypeChampion');
                    
                    pickOrderOption.classList.remove('selected', 'disabled');
                    championOption.classList.remove('selected', 'disabled');
                    
                    // Determine which trade types are available
                    const canPickOrderTrade = !localPlayerHasPicked && !targetHasPicked;
                    const canChampionTrade = localPlayerHasPicked && targetHasPicked;
                    
                    // Disable unavailable options
                    if (!canPickOrderTrade) {
                        pickOrderOption.classList.add('disabled');
                        pickOrderOption.title = 'Both players must not have picked yet';
                    } else {
                        pickOrderOption.title = 'Swap pick positions';
                    }
                    
                    if (!canChampionTrade) {
                        championOption.classList.add('disabled');
                        championOption.title = 'Both players must have picked champions';
                    } else {
                        championOption.title = 'Swap champions';
                    }
                    
                    // Auto-select available option if only one is available
                    if (canPickOrderTrade && !canChampionTrade) {
                        selectTradeType('PICK_ORDER');
                    } else if (!canPickOrderTrade && canChampionTrade) {
                        selectTradeType('CHAMPION');
                    } else {
                        document.getElementById('tradePreviewContent').textContent = 'Select a trade type';
                        document.getElementById('confirmTradeBtn').disabled = true;
                    }
                    
                    // Show modal
                    document.getElementById('tradeModal').classList.add('active');
                }
                
                // Close trade modal
                function closeTradeModal() {
                    document.getElementById('tradeModal').classList.remove('active');
                    tradeModalState = {
                        targetCellId: null,
                        targetSummonerName: '',
                        selectedType: null
                    };
                }
                
                // Select trade type
                function selectTradeType(type) {
                    // Check if option is disabled
                    const option = document.getElementById(type === 'PICK_ORDER' ? 'tradeTypePickOrder' : 'tradeTypeChampion');
                    if (option.classList.contains('disabled')) {
                        const message = type === 'PICK_ORDER' 
                            ? 'Pick order trades are only available before champions are picked'
                            : 'Champion trades require both players to have picked champions first';
                        showError(message);
                        return;
                    }
                    
                    tradeModalState.selectedType = type;
                    
                    // Update UI
                    document.getElementById('tradeTypePickOrder').classList.toggle('selected', type === 'PICK_ORDER');
                    document.getElementById('tradeTypeChampion').classList.toggle('selected', type === 'CHAMPION');
                    
                    // Update preview
                    const previewContent = document.getElementById('tradePreviewContent');
                    if (type === 'PICK_ORDER') {
                        previewContent.innerHTML = `
                            <span>Your pick order</span>
                            <span class="trade-preview-arrow">↔️</span>
                            <span>${tradeModalState.targetSummonerName}'s pick order</span>
                        `;
                    } else if (type === 'CHAMPION') {
                        previewContent.innerHTML = `
                            <span>Your champion</span>
                            <span class="trade-preview-arrow">↔️</span>
                            <span>${tradeModalState.targetSummonerName}'s champion</span>
                        `;
                    }
                    
                    // Enable confirm button
                    document.getElementById('confirmTradeBtn').disabled = false;
                }
                
                // Queue Control Functions
                let isQueueActive = false;
                
                async function startQueue() {
                    const selectedQueue = document.querySelector('input[name="queueType"]:checked');
                    if (!selectedQueue) {
                        showError('Please select a queue type');
                        return;
                    }
                    
                    const queueId = parseInt(selectedQueue.value);
                    const queueNames = {
                        420: 'Ranked Solo/Duo',
                        440: 'Ranked Flex',
                        400: 'Normal Draft',
                        430: 'Normal Blind',
                        450: 'ARAM'
                    };
                    
                    try {
                        console.log('🎮 Starting queue:', queueId);
                        
                        const { error } = await supabaseClient
                            .from('remote_commands')
                            .insert({
                                session_code: SESSION_CODE,
                                command_type: 'start_queue',
                                champion_id: queueId,  // Using champion_id field to store queue_id
                                executed: false
                            });
                        
                        if (error) throw error;
                        
                        // Update UI
                        isQueueActive = true;
                        document.getElementById('startQueueBtn').disabled = true;
                        document.getElementById('stopQueueBtn').disabled = false;
                        document.getElementById('queueStatus').classList.remove('hidden');
                        
                        // Disable queue selection
                        document.querySelectorAll('input[name="queueType"]').forEach(input => {
                            input.disabled = true;
                        });
                        
                        showSuccess(`Starting ${queueNames[queueId]}...`);
                    } catch (error) {
                        console.error('Failed to start queue:', error);
                        showError('Failed to start queue');
                    }
                }
                
                async function stopQueue() {
                    try {
                        console.log('⏹️ Stopping queue');
                        
                        // Immediately update UI to prevent double-click issues
                        isQueueActive = false;
                        document.getElementById('startQueueBtn').disabled = false;
                        document.getElementById('stopQueueBtn').disabled = true;
                        document.getElementById('queueStatus').classList.add('hidden');
                        
                        // Enable queue selection
                        document.querySelectorAll('input[name="queueType"]').forEach(input => {
                            input.disabled = false;
                        });
                        
                        const { error } = await supabaseClient
                            .from('remote_commands')
                            .insert({
                                session_code: SESSION_CODE,
                                command_type: 'stop_queue',
                                champion_id: 0,  // Dummy value for stop command
                                executed: false
                            });
                        
                        if (error) throw error;
                        
                        showSuccess('Queue stopped');
                    } catch (error) {
                        console.error('Failed to stop queue:', error);
                        console.error('Error details:', JSON.stringify(error, null, 2));
                        showError(`Failed to stop queue: ${error.message || 'Unknown error'}`);
                        
                        // Revert UI on error
                        isQueueActive = true;
                        document.getElementById('startQueueBtn').disabled = true;
                        document.getElementById('stopQueueBtn').disabled = false;
                        document.getElementById('queueStatus').classList.remove('hidden');
                        document.querySelectorAll('input[name="queueType"]').forEach(input => {
                            input.disabled = true;
                        });
                    }
                }
                
                // Confirm and send trade request
                async function confirmTrade() {
                    if (!tradeModalState.selectedType || !tradeModalState.targetCellId) {
                        showError('Please select a trade type');
                        return;
                    }
                    
                    try {
                        console.log('📤 Sending trade request:', tradeModalState);
                        
                        const { error } = await supabaseClient
                            .from('remote_commands')
                            .insert([{
                                session_code: SESSION_CODE,
                                command_type: 'initiate_trade',
                                trade_type: tradeModalState.selectedType,
                                target_cell_id: tradeModalState.targetCellId,
                                details: {}
                            }]);
                        
                        if (error) throw error;
                        
                        showSuccess(`Trade request sent to ${tradeModalState.targetSummonerName}`);
                        closeTradeModal();
                    } catch (error) {
                        console.error('Failed to send trade request:', error);
                        showError('Failed to send trade request');
                    }
                }
                
                // Fetch game status immediately
                async function fetchGameStatus() {
                    try {
                        const { data: statusData, error: statusError } = await supabaseClient
                            .from('game_status')
                            .select('*')
                            .eq('session_code', SESSION_CODE)
                            .maybeSingle();
                        
                        if (!statusError && statusData) {
                            console.log('📥 Fetched game status:', statusData.game_phase);
                            updateGameStatus(statusData);
                        } else if (!statusError && !statusData) {
                            // No status yet, show default
                            console.log('📥 No game status yet, showing default');
                            updateGameStatus({
                                session_code: SESSION_CODE,
                                game_phase: 'None',
                                additional_data: {},
                                updated_at: new Date().toISOString()
                            });
                        }
                    } catch (error) {
                        console.error('Failed to fetch game status:', error);
                    }
                }
                
                // Fetch lobby state immediately
                async function fetchLobbyState() {
                    try {
                        const { data: lobbyData, error: lobbyError } = await supabaseClient
                            .from('lobby_state')
                            .select('*')
                            .eq('session_code', SESSION_CODE)
                            .maybeSingle();
                        
                        if (!lobbyError && lobbyData) {
                            console.log('📥 Fetched lobby state:', {
                                members: lobbyData.lobby_members?.length || 0,
                                queueId: lobbyData.queue_id
                            });
                            renderLobbyMembers(lobbyData);
                        } else {
                            console.log('📥 No lobby state yet');
                        }
                    } catch (error) {
                        console.error('Failed to fetch lobby state:', error);
                    }
                }
                
                // Poll for state updates (fallback) - Direct Supabase queries
                async function pollState() {
                    try {
                        // Get game status first (this determines if we show champion select UI)
                        const { data: statusData, error: statusError } = await supabaseClient
                            .from('game_status')
                            .select('*')
                            .eq('session_code', SESSION_CODE)
                            .maybeSingle();
                        
                        if (!statusError && statusData) {
                            console.log('📥 Received game status from Supabase:', statusData.game_phase);
                            updateGameStatus(statusData);
                        } else if (!statusError && !statusData) {
                            // No status yet, show default
                            updateGameStatus({
                                session_code: SESSION_CODE,
                                game_phase: 'None',
                                additional_data: {},
                                updated_at: new Date().toISOString()
                            });
                        }
                        
                        // Get champ select state (for owned champions list)
                        const { data: stateData, error: stateError } = await supabaseClient
                            .from('champ_select_state')
                            .select('*')
                            .eq('session_code', SESSION_CODE)
                            .maybeSingle();
                        
                        if (!stateError && stateData) {
                            console.log('📥 Received champ select state from Supabase');
                            updateState(stateData);
                        }
                    } catch (error) {
                        // Silently ignore polling errors
                        console.log('Poll state error (ignored):', error.message);
                    }
                }
                
                // Track if "Your Turn" overlay has been shown for current turn
                let yourTurnShown = false;
                let yourTurnTimer = null;
                
                // Update turn indicator based on whose turn it is
                function updateTurnIndicator(isMyTurn, activeAction) {
                    const turnIndicator = document.getElementById('turnIndicator');
                    if (!turnIndicator) return;
                    
                    const indicatorEl = turnIndicator.querySelector('div');
                    if (!indicatorEl) return;
                    
                    if (isMyTurn && activeAction) {
                        // Your turn - pulsing hourglass
                        indicatorEl.innerHTML = '<span class="hourglass-animate">⏳</span>';
                        indicatorEl.style.filter = 'drop-shadow(0 0 8px rgba(10, 200, 185, 0.6))';
                        
                        // Show "Your Turn" overlay if not shown yet
                        if (!yourTurnShown) {
                            showYourTurnOverlay(activeAction);
                            yourTurnShown = true;
                        }
                    } else {
                        // Not your turn - reset flag
                        yourTurnShown = false;
                        hideYourTurnOverlay();
                        
                        if (activeAction) {
                            // Someone else's turn - static hourglass
                            indicatorEl.textContent = '⏳';
                            indicatorEl.style.filter = 'grayscale(50%) opacity(0.5)';
                        } else {
                            // Waiting
                            indicatorEl.textContent = '⏸️';
                            indicatorEl.style.filter = 'grayscale(100%) opacity(0.3)';
                        }
                    }
                }
                
                // Show "Your Turn" overlay
                function showYourTurnOverlay(activeAction) {
                    const overlay = document.getElementById('yourTurnOverlay');
                    const icon = document.getElementById('yourTurnIcon');
                    const subtitle = document.getElementById('yourTurnSubtitle');
                    const timerEl = document.getElementById('yourTurnTimer');
                    
                    if (!overlay) return;
                    
                    // Set icon and text based on action type
                    if (activeAction.type === 'ban') {
                        icon.textContent = '🚫';
                        subtitle.textContent = 'Ban a champion now';
                    } else {
                        icon.textContent = '✅';
                        subtitle.textContent = 'Pick your champion now';
                    }
                    
                    // Show overlay
                    overlay.classList.add('active');
                    
                    // Start countdown timer if time_left is available
                    if (currentState && currentState.time_left) {
                        let timeLeft = Math.floor(currentState.time_left / 1000);
                        timerEl.textContent = timeLeft + 's';
                        
                        // Clear existing timer
                        if (yourTurnTimer) {
                            clearInterval(yourTurnTimer);
                        }
                        
                        // Update timer every second
                        yourTurnTimer = setInterval(() => {
                            timeLeft--;
                            if (timeLeft >= 0) {
                                timerEl.textContent = timeLeft + 's';
                            } else {
                                clearInterval(yourTurnTimer);
                                yourTurnTimer = null;
                            }
                        }, 1000);
                    } else {
                        timerEl.textContent = '--';
                    }
                }
                
                // Hide "Your Turn" overlay
                function hideYourTurnOverlay() {
                    const overlay = document.getElementById('yourTurnOverlay');
                    if (overlay) {
                        overlay.classList.remove('active');
                    }
                    
                    // Clear timer
                    if (yourTurnTimer) {
                        clearInterval(yourTurnTimer);
                        yourTurnTimer = null;
                    }
                }
                
                // Dismiss "Your Turn" overlay (user clicked button)
                function dismissYourTurn() {
                    hideYourTurnOverlay();
                }
                
                // Update UI with champ select state
                let lastStateHash = '';
                
                function updateState(state) {
                    console.log('🎯 updateState called with state:', state);
                    
                    // Create a hash of the state to detect meaningful changes
                    const stateHash = JSON.stringify({
                        phase: state?.phase,
                        my_team: state?.my_team?.map(m => ({ 
                            cellId: m.cellId, 
                            championId: m.championId, 
                            isLocked: m.isChampionLocked,
                            summonerName: m.summonerName 
                        })),
                        enemy_team: state?.enemy_team?.map(m => ({ 
                            cellId: m.cellId, 
                            championId: m.championId, 
                            isLocked: m.isChampionLocked 
                        })),
                        banned_champions: state?.banned_champions,
                        actions: state?.actions?.flat().map(a => ({ 
                            id: a.id, 
                            completed: a.completed, 
                            championId: a.championId 
                        })),
                        local_player_cell_id: state?.local_player_cell_id
                    });
                    
                    // Skip update if state hasn't changed (prevents flickering)
                    if (stateHash === lastStateHash) {
                        console.log('⏭️ State unchanged, skipping render');
                        return;
                    }
                    
                    lastStateHash = stateHash;
                    console.log('✅ State changed, updating UI');
                    
                    console.log('📊 State details:', {
                        phase: state?.phase,
                        myTeamCount: state?.my_team?.length,
                        enemyTeamCount: state?.enemy_team?.length,
                        localPlayerPosition: state?.local_player_position,
                        pickOrderSequence: state?.pick_order_sequence,
                        currentActivePickIndex: state?.current_active_pick_index,
                        bannedChampions: state?.banned_champions?.length
                    });
                    
                    currentState = state;
                    
                    // Check if owned champions changed
                    const oldOwnedCount = ownedChampionIds.length;
                    let ownedChampionsChanged = false;
                    
                    if (state.owned_champions && Array.isArray(state.owned_champions)) {
                        // Check if the list actually changed
                        if (oldOwnedCount !== state.owned_champions.length) {
                            ownedChampionsChanged = true;
                        }
                        ownedChampionIds = state.owned_champions;
                        console.log('✅ Owned champions:', ownedChampionIds.length);
                    }
                    
                    // Update turn and phase info
                    updateTurnAndPhase(state);
                    
                    // Update teams display
                    updateTeamsDisplay(state);
                    
                    // Only re-render champions if owned champions list changed
                    // This prevents constant re-rendering that clears search input
                    if (ownedChampionsChanged && champions.length > 0) {
                        console.log('✅ Owned champions changed, re-rendering');
                        renderChampions();
                    }
                }
                
                // Update turn and phase information
                function updateTurnAndPhase(state) {
                    console.log('🎯 updateTurnAndPhase called');
                    const turnInfo = document.getElementById('turnInfo');
                    const currentPhaseText = document.getElementById('currentPhaseText');
                    const currentActionText = document.getElementById('currentActionText');
                    
                    if (!state) {
                        console.warn('⚠️ No state for turn/phase');
                        turnInfo.classList.add('hidden');
                        return;
                    }
                    
                    turnInfo.classList.remove('hidden');
                    
                    // Determine current phase
                    const phase = state.phase || 'PLANNING';
                    
                    console.log('🎯 Turn info:', {
                        phase,
                        local_player_cell_id: state.local_player_cell_id
                    });
                    
                    // Find active action
                    let activeAction = null;
                    let isMyTurn = false;
                    
                    if (state.actions && Array.isArray(state.actions)) {
                        console.log('🎬 Actions:', state.actions);
                        for (const actionGroup of state.actions) {
                            if (Array.isArray(actionGroup)) {
                                for (const action of actionGroup) {
                                    // Skip phase_transition actions
                                    if (action.type === 'phase_transition') {
                                        continue;
                                    }
                                    
                                    console.log('🎬 Action:', action, 'completed:', action.completed, 'actorCellId:', action.actorCellId, 'myId:', state.local_player_cell_id);
                                    if (!action.completed && action.actorCellId === state.local_player_cell_id) {
                                        activeAction = action;
                                        isMyTurn = true;
                                        console.log('✅ Found MY active action:', action);
                                        break;
                                    }
                                    if (!action.completed && !activeAction) {
                                        activeAction = action;
                                        console.log('👀 Found active action (not mine):', action);
                                    }
                                }
                                
                                // If we found our action, stop searching
                                if (isMyTurn) break;
                            }
                        }
                    } else {
                        console.warn('⚠️ No actions in state');
                    }
                    
                    console.log('🎯 Action result:', {
                        activeAction,
                        isMyTurn
                    });
                    
                    // Auto-switch tab based on phase and active action
                    console.log('🔍 Mode switching check:', {
                        phase,
                        currentMode,
                        hasActiveAction: !!activeAction,
                        activeActionType: activeAction?.type,
                        isMyTurn
                    });
                    
                    if (activeAction && isMyTurn) {
                        const shouldBeBanMode = activeAction.type === 'ban';
                        const shouldBePickMode = activeAction.type === 'pick';
                        
                        console.log('✅ Active action detected:', {
                            shouldBeBanMode,
                            shouldBePickMode,
                            currentMode
                        });
                        
                        if (shouldBeBanMode && currentMode !== 'ban') {
                            console.log('🔄 Auto-switching to BAN mode (your turn to ban)');
                            switchMode('ban');
                        } else if (shouldBePickMode && currentMode !== 'pick') {
                            console.log('🔄 Auto-switching to PICK mode (your turn to pick)');
                            switchMode('pick');
                        }
                    } else if (phase === 'BAN_PHASE' && currentMode !== 'ban') {
                        console.log('🔄 Auto-switching to BAN mode (ban phase)');
                        switchMode('ban');
                    } else if ((phase === 'PICK_PHASE' || phase === 'PICK_ONLY') && currentMode !== 'pick') {
                        console.log('🔄 Auto-switching to PICK mode (pick phase)');
                        switchMode('pick');
                    } else {
                        console.log('⏸️ No mode switch needed');
                    }
                    
                    // Determine actual phase based on active action
                    let actualPhase = phase;
                    if (phase === 'BAN_PICK' && activeAction) {
                        actualPhase = activeAction.type === 'ban' ? 'BAN_PHASE' : 'PICK_PHASE';
                    }
                    
                    // Update phase text
                    const phaseMap = {
                        'BAN_PHASE': 'Ban Phase',
                        'PICK_PHASE': 'Pick Phase',
                        'BAN_PICK': activeAction?.type === 'ban' ? 'Ban Phase' : 'Pick Phase',
                        'PICK_ONLY': 'Pick Phase',
                        'PLANNING': 'Planning',
                        'FINALIZATION': 'Finalizing'
                    };
                    
                    currentPhaseText.textContent = phaseMap[phase] || phase;
                    
                    // Update action text and enable/disable champion selection
                    const championGrid = document.getElementById('championGrid');
                    const actionBtn = document.getElementById('actionBtn');
                    
                    console.log('🔍 UI Update:', {
                        isMyTurn,
                        hasActiveAction: !!activeAction,
                        actionType: activeAction?.type
                    });
                    
                    // Update global turn state
                    isMyTurnGlobal = isMyTurn && !!activeAction;
                    
                    if (isMyTurn && activeAction) {
                        const actionType = activeAction.type === 'ban' ? 'BAN' : 'PICK';
                        currentActionText.textContent = `🎯 YOUR TURN TO ${actionType}!`;
                        currentActionText.style.color = '#0ac8b9';
                        currentActionText.style.animation = 'pulse 1.5s infinite';
                        
                        // Enable champion selection
                        console.log('✅ Enabling champion selection (your turn)');
                        championGrid.style.opacity = '1';
                        championGrid.style.pointerEvents = 'auto';
                        championGrid.style.filter = 'none';
                    } else if (activeAction) {
                        const actionType = activeAction.type === 'ban' ? 'banning' : 'picking';
                        currentActionText.textContent = `⏳ Waiting for teammate ${actionType}...`;
                        currentActionText.style.color = '#f0ad4e';
                        currentActionText.style.animation = 'none';
                        
                        // Disable champion selection
                        console.log('⏳ Disabling champion selection (not your turn)');
                        championGrid.style.opacity = '0.5';
                        championGrid.style.pointerEvents = 'none';
                        championGrid.style.filter = 'grayscale(50%)';
                        
                        // Disable action button
                        if (selectedChampion) {
                            selectedChampion = null;
                            actionBtn.disabled = true;
                            document.querySelectorAll('.champion-card').forEach(card => {
                                card.classList.remove('selected');
                            });
                            document.getElementById('selectedChampionInfo').classList.add('hidden');
                        }
                    } else {
                        currentActionText.textContent = 'Waiting...';
                        currentActionText.style.color = '#a09b8c';
                        currentActionText.style.animation = 'none';
                        
                        // Disable champion selection
                        console.log('⏳ Disabling champion selection (no action)');
                        championGrid.style.opacity = '0.5';
                        championGrid.style.pointerEvents = 'none';
                        championGrid.style.filter = 'grayscale(50%)';
                    }
                    
                    // Update turn indicator
                    updateTurnIndicator(isMyTurn, activeAction);
                }
                
                // Get position icon HTML
                function getPositionIcon(position, size = 'small') {
                    // Use Riot's official position icons from Data Dragon
                    const positionMap = {
                        'top': { icon: 'https://raw.communitydragon.org/latest/plugins/rcp-fe-lol-champ-select/global/default/svg/position-top.svg', name: 'Top' },
                        'jungle': { icon: 'https://raw.communitydragon.org/latest/plugins/rcp-fe-lol-champ-select/global/default/svg/position-jungle.svg', name: 'Jungle' },
                        'middle': { icon: 'https://raw.communitydragon.org/latest/plugins/rcp-fe-lol-champ-select/global/default/svg/position-middle.svg', name: 'Mid' },
                        'bottom': { icon: 'https://raw.communitydragon.org/latest/plugins/rcp-fe-lol-champ-select/global/default/svg/position-bottom.svg', name: 'Bot' },
                        'utility': { icon: 'https://raw.communitydragon.org/latest/plugins/rcp-fe-lol-champ-select/global/default/svg/position-utility.svg', name: 'Support' }
                    };
                    
                    const pos = positionMap[position];
                    if (!pos) {
                        console.log('⚠️ Unknown position:', position);
                        return '';
                    }
                    
                    const className = size === 'large' ? 'position-icon-large' : 'position-icon';
                    return `<div class="${className}" title="${pos.name}"><img src="${pos.icon}" alt="${pos.name}"></div>`;
                }
                
                // Track previous position for change detection
                let previousPosition = null;
                
                // Update your position display
                function updateYourPosition(position) {
                    const yourPosition = document.getElementById('yourPosition');
                    const yourPositionIcon = document.getElementById('yourPositionIcon');
                    const yourPositionText = document.getElementById('yourPositionText');
                    
                    if (!position || position === '') {
                        yourPosition.classList.add('hidden');
                        return;
                    }
                    
                    // Check if position changed
                    const positionChanged = previousPosition && previousPosition !== position;
                    previousPosition = position;
                    
                    yourPosition.classList.remove('hidden');
                    
                    const positionNames = {
                        'top': 'Top Lane',
                        'jungle': 'Jungle',
                        'middle': 'Mid Lane',
                        'bottom': 'Bot Lane',
                        'utility': 'Support'
                    };
                    
                    yourPositionIcon.innerHTML = getPositionIcon(position, 'large');
                    yourPositionText.textContent = positionNames[position] || position;
                    
                    // Animate if position changed
                    if (positionChanged) {
                        console.log('🔄 Position changed from', previousPosition, 'to', position);
                        yourPosition.classList.add('position-updated');
                        yourPositionIcon.classList.add('position-changed');
                        
                        // Remove animation classes after animation completes
                        setTimeout(() => {
                            yourPosition.classList.remove('position-updated');
                            yourPositionIcon.classList.remove('position-changed');
                        }, 600);
                    }
                }
                
                // Update teams display
                function updateTeamsDisplay(state) {
                    console.log('👥 updateTeamsDisplay called');
                    const teamsDisplay = document.getElementById('teamsDisplay');
                    const myTeamDisplay = document.getElementById('myTeamDisplay');
                    const enemyTeamDisplay = document.getElementById('enemyTeamDisplay');
                    const bansSection = document.getElementById('bansSection');
                    const myTeamBans = document.getElementById('myTeamBans');
                    const enemyTeamBans = document.getElementById('enemyTeamBans');
                    
                    if (!state || !state.my_team || !state.enemy_team) {
                        console.warn('⚠️ No team data:', {
                            hasState: !!state,
                            hasMyTeam: !!state?.my_team,
                            hasEnemyTeam: !!state?.enemy_team
                        });
                        teamsDisplay.classList.add('hidden');
                        return;
                    }
                    
                    console.log('✅ Team data found:', {
                        myTeamSize: state.my_team.length,
                        enemyTeamSize: state.enemy_team.length,
                        myTeam: state.my_team,
                        enemyTeam: state.enemy_team,
                        localPlayerPosition: state.local_player_position
                    });
                    
                    teamsDisplay.classList.remove('hidden');
                    
                    // Update your position display
                    if (state.local_player_position) {
                        updateYourPosition(state.local_player_position);
                    }
                    
                    const ddVersion = window.DD_VERSION || '15.1.1';
                    
                    // Get pick order sequence and current picker
                    const pickOrderSequence = state.pick_order_sequence || [];
                    const currentActivePickIndex = state.current_active_pick_index || -1;
                    
                    // Find current picker cellId
                    let currentPickerCellId = null;
                    if (currentActivePickIndex >= 0 && pickOrderSequence[currentActivePickIndex]) {
                        currentPickerCellId = pickOrderSequence[currentActivePickIndex].cellId;
                    }
                    
                    console.log('🎯 Pick order info:', {
                        pickOrderSequence,
                        currentActivePickIndex,
                        currentPickerCellId
                    });
                    
                    // Update account info with summoner details
                    if (state.local_player_summoner_name && state.local_player_summoner_name !== 'Unknown') {
                        const accountInfo = document.getElementById('accountInfo');
                        const accountName = document.getElementById('accountName');
                        const accountLevel = document.getElementById('accountLevel');
                        const accountIcon = document.getElementById('accountIcon');
                        
                        if (accountInfo && accountName && accountLevel && accountIcon) {
                            accountInfo.classList.remove('hidden');
                            accountName.textContent = state.local_player_summoner_name;
                            accountLevel.textContent = `Level: ${state.local_player_summoner_level || '--'}`;
                            
                            // Set profile icon
                            if (state.local_player_profile_icon_id && state.local_player_profile_icon_id > 0) {
                                const ddVersion = window.DD_VERSION || '15.1.1';
                                accountIcon.src = `https://ddragon.leagueoflegends.com/cdn/${ddVersion}/img/profileicon/${state.local_player_profile_icon_id}.png`;
                            }
                        }
                    }
                    
                    // Render my team with position icons, pick order badges, and summoner names
                    myTeamDisplay.innerHTML = state.my_team.map((member, index) => {
                        console.log(`👤 Team member ${index}:`, {
                            summonerName: member.summonerName,
                            position: member.assignedPosition,
                            cellId: member.cellId,
                            championId: member.championId,
                            isLocalPlayer: member.isLocalPlayer,
                            isLocked: member.isChampionLocked
                        });
                        
                        const isActive = member.cellId === state.local_player_cell_id && 
                                        state.actions?.flat().some(a => !a.completed && a.actorCellId === member.cellId);
                        
                        const isPicking = member.cellId === currentPickerCellId;
                        const isLocalPlayer = member.isLocalPlayer || false;
                        const isLocked = member.isChampionLocked || false;
                        const summonerName = member.summonerName || 'Unknown';
                        
                        const position = member.assignedPosition || '';
                        console.log(`🎯 Member ${summonerName} position:`, position, 'icon:', position ? 'will render' : 'NO POSITION');
                        const positionIconHtml = position ? getPositionIcon(position) : '';
                        
                        // Position text
                        const positionNames = {
                            'top': 'TOP',
                            'jungle': 'JUNGLE',
                            'middle': 'MID',
                            'bottom': 'BOT',
                            'utility': 'SUP'
                        };
                        const positionText = position ? positionNames[position] || position.toUpperCase() : '';
                        
                        // Find pick order for this member
                        const pickOrderInfo = pickOrderSequence.find(p => p.cellId === member.cellId);
                        const pickOrderBadge = pickOrderInfo ? `<div class="pick-order-badge">${pickOrderInfo.pickOrder}</div>` : '';
                        
                        const memberClass = isPicking ? 'picking' : (isActive ? 'active' : '');
                        const nameClass = isLocalPlayer ? 'local-player' : '';
                        
                        // Lock/hover indicators
                        const lockIndicator = isLocked ? '<div class="team-member-lock-indicator">🔒</div>' : '';
                        const hoverIndicator = (!isLocked && member.championPickIntent > 0) ? '<div class="team-member-hover-indicator">👁️</div>' : '';
                        
                        // Determine trade eligibility
                        const localPlayerMember = state.my_team.find(m => m.isLocalPlayer);
                        const localPlayerHasPicked = localPlayerMember && localPlayerMember.isChampionLocked;
                        const targetHasPicked = isLocked;
                        
                        // Can always trade if not yourself
                        const canTrade = !isLocalPlayer;
                        const tradeButtonDisabled = !canTrade ? 'disabled' : '';
                        
                        let tradeButtonTitle = 'Request trade';
                        if (isLocalPlayer) {
                            tradeButtonTitle = 'Cannot trade with yourself';
                        } else if (!localPlayerHasPicked && !targetHasPicked) {
                            tradeButtonTitle = 'Pick order trade';
                        } else if (localPlayerHasPicked && targetHasPicked) {
                            tradeButtonTitle = 'Champion trade';
                        } else {
                            tradeButtonTitle = 'Pick order trade';
                        }
                        
                        // Add trade button for non-local players
                        const tradeButton = !isLocalPlayer ? `<button class="trade-button" ${tradeButtonDisabled} title="${tradeButtonTitle}" onclick="openTradeModal(${member.cellId}, '${summonerName}', ${canTrade}, ${localPlayerHasPicked}, ${targetHasPicked})">Trade</button>` : '';
                        
                        if (member.championId && member.championId > 0) {
                            const champ = champions.find(c => parseInt(c.key) === member.championId);
                            if (champ) {
                                return `
                                    <div class="team-member-wrapper">
                                        ${pickOrderBadge}
                                        <div class="team-member ${memberClass}" title="${summonerName} - ${champ.name}">
                                            <img src="https://ddragon.leagueoflegends.com/cdn/${ddVersion}/img/champion/${champ.id}.png" alt="${champ.name}">
                                            ${lockIndicator}
                                            ${hoverIndicator}
                                        </div>
                                        ${positionIconHtml ? `<div class="team-member-position">${positionIconHtml}</div>` : ''}
                                        <div class="team-member-name ${nameClass}">${summonerName}</div>
                                        ${positionText ? `<div class="team-member-role">${positionText}</div>` : ''}
                                        ${tradeButton}
                                    </div>
                                `;
                            }
                        }
                        
                        return `
                            <div class="team-member-wrapper">
                                ${pickOrderBadge}
                                <div class="team-member-placeholder ${memberClass}" title="${summonerName}">?</div>
                                ${positionIconHtml ? `<div class="team-member-position">${positionIconHtml}</div>` : ''}
                                <div class="team-member-name ${nameClass}">${summonerName}</div>
                                ${positionText ? `<div class="team-member-role">${positionText}</div>` : ''}
                                ${tradeButton}
                            </div>
                        `;
                    }).join('');
                    
                    // Render enemy team with position icons, summoner names, and lock status
                    enemyTeamDisplay.innerHTML = state.enemy_team.map(member => {
                        const position = member.assignedPosition || '';
                        const positionIconHtml = position ? getPositionIcon(position) : '';
                        const summonerName = member.summonerName || 'Unknown';
                        const isLocked = member.isChampionLocked || false;
                        
                        // Lock/hover indicators
                        const lockIndicator = isLocked ? '<div class="team-member-lock-indicator">🔒</div>' : '';
                        const hoverIndicator = (!isLocked && member.championPickIntent > 0) ? '<div class="team-member-hover-indicator">👁️</div>' : '';
                        
                        if (member.championId && member.championId > 0) {
                            const champ = champions.find(c => parseInt(c.key) === member.championId);
                            if (champ) {
                                return `
                                    <div class="team-member-wrapper">
                                        <div class="team-member" title="${summonerName} - ${champ.name}">
                                            <img src="https://ddragon.leagueoflegends.com/cdn/${ddVersion}/img/champion/${champ.id}.png" alt="${champ.name}">
                                            ${lockIndicator}
                                            ${hoverIndicator}
                                        </div>
                                        ${positionIconHtml ? `<div class="team-member-position">${positionIconHtml}</div>` : ''}
                                        <div class="team-member-name">${summonerName}</div>
                                    </div>
                                `;
                            }
                        }
                        
                        return `
                            <div class="team-member-wrapper">
                                <div class="team-member-placeholder" title="${summonerName}">?</div>
                                ${positionIconHtml ? `<div class="team-member-position">${positionIconHtml}</div>` : ''}
                                <div class="team-member-name">${summonerName}</div>
                            </div>
                        `;
                    }).join('');
                    
                    // Extract and display bans from banned_champions field
                    const myBans = [];
                    const enemyBans = [];
                    
                    console.log('🚫 Bans section check:', {
                        hasBannedChampions: !!state.banned_champions,
                        isArray: Array.isArray(state.banned_champions),
                        bannedChampionsData: state.banned_champions,
                        championsLoaded: champions.length > 0
                    });
                    
                    if (state.banned_champions && Array.isArray(state.banned_champions)) {
                        console.log('🚫 Processing banned champions:', state.banned_champions);
                        
                        state.banned_champions.forEach(ban => {
                            console.log('🔍 Looking for champion:', ban.championId, 'teamId:', ban.teamId);
                            const champ = champions.find(c => parseInt(c.key) === ban.championId);
                            console.log('🔍 Found champion:', champ ? champ.name : 'NOT FOUND');
                            
                            if (champ) {
                                const banHtml = `
                                    <div class="banned-champion" title="${champ.name} (Banned)">
                                        <img src="https://ddragon.leagueoflegends.com/cdn/${ddVersion}/img/champion/${champ.id}.png" alt="${champ.name}">
                                    </div>
                                `;
                                
                                // teamId: 100 = ally, 200 = enemy
                                if (ban.teamId === 100) {
                                    myBans.push(banHtml);
                                    console.log('✅ Added to myBans:', champ.name);
                                } else if (ban.teamId === 200) {
                                    enemyBans.push(banHtml);
                                    console.log('✅ Added to enemyBans:', champ.name);
                                }
                            }
                        });
                    }
                    
                    console.log('🚫 Bans processed:', {
                        myBansCount: myBans.length,
                        enemyBansCount: enemyBans.length,
                        willShowSection: myBans.length > 0 || enemyBans.length > 0
                    });
                    
                    // Show bans section if there are any bans
                    if (myBans.length > 0 || enemyBans.length > 0) {
                        console.log('✅ Showing bans section');
                        bansSection.classList.remove('hidden');
                        
                        // Show ban count
                        const myBanCount = myBans.length;
                        const enemyBanCount = enemyBans.length;
                        
                        myTeamBans.innerHTML = myBans.length > 0 
                            ? myBans.join('') 
                            : '<div style="font-size: 10px; color: #5b5a56; padding: 8px;">No bans yet</div>';
                        
                        enemyTeamBans.innerHTML = enemyBans.length > 0 
                            ? enemyBans.join('') 
                            : '<div style="font-size: 10px; color: #5b5a56; padding: 8px;">No bans yet</div>';
                        
                        console.log('✅ Bans rendered:', { 
                            myBans: myBanCount, 
                            enemyBans: enemyBanCount,
                            total: myBanCount + enemyBanCount 
                        });
                    } else {
                        console.log('ℹ️ Hiding bans section (no bans)');
                        bansSection.classList.add('hidden');
                    }
                    
                    console.log('✅ Teams rendered');
                }
                
                // Update game status display
                function updateGameStatus(status) {
                    const inlineStatus = document.getElementById('gameStatusInline');
                    const icon = document.getElementById('gameStatusIcon');
                    const title = document.getElementById('gameStatusTitle');
                    const subtitle = document.getElementById('gameStatusSubtitle');
                    
                    inlineStatus.classList.remove('hidden');
                    
                    const phase = status.game_phase || 'None';
                    
                    // Update account info if available in additional_data
                    console.log('🔍 Game status additional_data:', status.additional_data);
                    if (status.additional_data) {
                        const summonerName = status.additional_data.summoner_name;
                        const summonerTag = status.additional_data.summoner_tag;
                        const profileIconId = status.additional_data.profile_icon_id;
                        const summonerLevel = status.additional_data.summoner_level;
                        const rankedTier = status.additional_data.ranked_tier;
                        const rankedDivision = status.additional_data.ranked_division;
                        const rankedLP = status.additional_data.ranked_lp;
                        
                        console.log('👤 Summoner info from game status:', {
                            summonerName,
                            summonerTag,
                            profileIconId,
                            summonerLevel,
                            rankedTier,
                            rankedDivision,
                            rankedLP
                        });
                        
                        if (summonerName && summonerName !== 'Unknown') {
                            const accountInfo = document.getElementById('accountInfo');
                            const accountName = document.getElementById('accountName');
                            const accountLevel = document.getElementById('accountLevel');
                            const accountIcon = document.getElementById('accountIcon');
                            
                            if (accountInfo && accountName && accountLevel && accountIcon) {
                                console.log('✅ Updating account info UI');
                                accountInfo.classList.remove('hidden');
                                
                                // Show name with tag (Riot ID format)
                                const fullName = summonerTag ? `${summonerName}#${summonerTag}` : summonerName;
                                accountName.textContent = fullName;
                                
                                // Show level and rank
                                let levelText = `Level: ${summonerLevel || '--'}`;
                                if (rankedTier && rankedTier !== 'UNRANKED') {
                                    const tierName = rankedTier.charAt(0) + rankedTier.slice(1).toLowerCase();
                                    const rankText = rankedDivision ? `${tierName} ${rankedDivision}` : tierName;
                                    levelText += ` • ${rankText}`;
                                    if (rankedLP !== undefined) {
                                        levelText += ` (${rankedLP} LP)`;
                                    }
                                }
                                accountLevel.textContent = levelText;
                                
                                // Set profile icon
                                if (profileIconId && profileIconId > 0) {
                                    const ddVersion = window.DD_VERSION || '15.1.1';
                                    accountIcon.src = `https://ddragon.leagueoflegends.com/cdn/${ddVersion}/img/profileicon/${profileIconId}.png`;
                                    console.log('✅ Profile icon set:', accountIcon.src);
                                } else {
                                    console.warn('⚠️ No valid profile icon ID');
                                }
                                
                                // Set rank badge icon
                                const rankBadge = document.getElementById('rankBadge');
                                const rankIcon = document.getElementById('rankIcon');
                                if (rankedTier && rankedTier !== 'UNRANKED' && rankBadge && rankIcon) {
                                    // Riot uses ranked emblems from their CDN
                                    // Format: https://raw.communitydragon.org/latest/plugins/rcp-fe-lol-static-assets/global/default/images/ranked-emblem/emblem-{tier}.png
                                    const tierLower = rankedTier.toLowerCase();
                                    rankIcon.src = `https://raw.communitydragon.org/latest/plugins/rcp-fe-lol-static-assets/global/default/images/ranked-emblem/emblem-${tierLower}.png`;
                                    rankBadge.classList.remove('hidden');
                                    console.log('✅ Rank icon set:', rankIcon.src);
                                } else if (rankBadge) {
                                    rankBadge.classList.add('hidden');
                                }
                            } else {
                                console.error('❌ Account info elements not found');
                            }
                        } else {
                            console.warn('⚠️ Summoner name is Unknown or missing');
                        }
                    } else {
                        console.warn('⚠️ No additional_data in game status');
                    }
                    
                    // Update icon and text based on phase
                    const statusMap = {
                        'None': { icon: '⏳', title: 'Waiting', subtitle: 'Not in game' },
                        'Lobby': { icon: '🏠', title: 'In Lobby', subtitle: 'Waiting for queue' },
                        'Matchmaking': { icon: '🔍', title: 'Finding Match', subtitle: 'Searching for players' },
                        'ReadyCheck': { icon: '✋', title: 'Ready Check', subtitle: 'Accept the match' },
                        'ChampSelect': { icon: '🎯', title: 'Champion Select', subtitle: 'Pick or ban your champion' },
                        'InProgress': { icon: '⚔️', title: 'In Game', subtitle: 'Match in progress' },
                        'WaitingForStats': { icon: '📊', title: 'Game Ending', subtitle: 'Waiting for stats' },
                        'EndOfGame': { icon: '🏆', title: 'Game Ended', subtitle: 'Match complete' }
                    };
                    
                    const statusInfo = statusMap[phase] || statusMap['None'];
                    icon.textContent = statusInfo.icon;
                    title.textContent = statusInfo.title;
                    subtitle.textContent = statusInfo.subtitle;
                    
                    // Show/hide UI elements based on game phase
                    const currentActionDisplay = document.getElementById('currentActionDisplay');
                    const championSelect = document.getElementById('championSelect');
                    const actionButtonContainer = document.getElementById('actionButtonContainer');
                    const queueControl = document.getElementById('queueControl');
                    
                    // Show queue control only when not in game (Lobby, None, or Matchmaking)
                    if (phase === 'None' || phase === 'Lobby' || phase === 'Matchmaking') {
                        queueControl?.classList.remove('hidden');
                        
                        // If in matchmaking, update queue status
                        if (phase === 'Matchmaking') {
                            isQueueActive = true;
                            document.getElementById('startQueueBtn').disabled = true;
                            document.getElementById('stopQueueBtn').disabled = false;
                            document.getElementById('queueStatus').classList.remove('hidden');
                        } else {
                            // Not in matchmaking anymore, reset queue UI
                            isQueueActive = false;
                            document.getElementById('startQueueBtn').disabled = false;
                            document.getElementById('stopQueueBtn').disabled = true;
                            document.getElementById('queueStatus').classList.add('hidden');
                            document.querySelectorAll('input[name="queueType"]').forEach(input => {
                                input.disabled = false;
                            });
                        }
                    } else {
                        queueControl?.classList.add('hidden');
                    }
                    
                    if (phase === 'ChampSelect') {
                        console.log('👁️ Showing champion select UI (game phase is ChampSelect)');
                        console.log('📊 Debug info:', {
                            championsLoaded: champions.length,
                            ownedChampionsCount: ownedChampionIds.length,
                            hasCurrentState: !!currentState,
                            currentMode: currentMode
                        });
                        
                        document.getElementById('turnInfo')?.classList.remove('hidden');
                        document.getElementById('teamsDisplay')?.classList.remove('hidden');
                        currentActionDisplay.classList.remove('hidden');
                        championSelect.classList.remove('hidden');
                        actionButtonContainer.classList.remove('hidden');
                        
                        // Always render champions when in ChampSelect
                        // If no owned champions yet, show all in ban mode or wait for state
                        if (champions.length > 0) {
                            console.log('✅ Rendering champions...');
                            renderChampions();
                        } else {
                            console.warn('⚠️ No champions loaded yet, waiting...');
                        }
                    } else {
                        console.log('👁️ Hiding champion select UI (game phase is not ChampSelect)');
                        document.getElementById('turnInfo')?.classList.add('hidden');
                        document.getElementById('teamsDisplay')?.classList.add('hidden');
                        currentActionDisplay.classList.add('hidden');
                        championSelect.classList.add('hidden');
                        actionButtonContainer.classList.add('hidden');
                        
                        // Clear selection
                        selectedChampion = null;
                        document.querySelectorAll('.champion-card').forEach(card => {
                            card.classList.remove('selected');
                        });
                    }
                }

                
                // Update connection status
                function updateConnectionStatus(status) {
                    const statusEl = document.getElementById('connectionStatus');
                    const dot = statusEl.querySelector('.status-dot');
                    const text = statusEl.querySelector('span');
                    
                    if (status === 'connected') {
                        dot.className = 'status-dot connected';
                        text.textContent = 'Connected';
                    } else {
                        dot.className = 'status-dot disconnected';
                        text.textContent = 'Disconnected';
                    }
                }
                
                // Show error
                function showError(message) {
                    const errorEl = document.getElementById('errorMessage');
                    const successEl = document.getElementById('successMessage');
                    
                    errorEl.textContent = message;
                    errorEl.classList.remove('hidden');
                    successEl.classList.add('hidden');
                    
                    setTimeout(() => {
                        errorEl.classList.add('hidden');
                    }, 5000);
                }
                
                // Show success
                function showSuccess(message) {
                    const successEl = document.getElementById('successMessage');
                    const errorEl = document.getElementById('errorMessage');
                    
                    successEl.textContent = message;
                    successEl.classList.remove('hidden');
                    errorEl.classList.add('hidden');
                    
                    setTimeout(() => {
                        successEl.classList.add('hidden');
                    }, 3000);
                }
                
                // Subscribe to lobby state
                function subscribeToLobbyState() {
                    console.log('🔔 Subscribing to lobby_state changes...');
                    supabaseClient
                        .channel(`lobby_state:${SESSION_CODE}`)
                        .on('postgres_changes', {
                            event: '*',
                            schema: 'public',
                            table: 'lobby_state',
                            filter: `session_code=eq.${SESSION_CODE}`
                        }, (payload) => {
                            console.log('📨 Lobby state update received:', payload);
                            if (payload.new) {
                                renderLobbyMembers(payload.new);
                            }
                        })
                        .subscribe((status) => {
                            console.log('🔔 Lobby subscription status:', status);
                        });
                }
                
                // Render lobby members
                function renderLobbyMembers(lobbyState) {
                    console.log('👥 renderLobbyMembers called with:', lobbyState);
                    
                    const lobbyMembers = document.getElementById('lobbyMembers');
                    const lobbyMembersList = document.getElementById('lobbyMembersList');
                    const positionSelection = document.getElementById('positionSelection');
                    
                    console.log('👥 Elements found:', {
                        lobbyMembers: !!lobbyMembers,
                        lobbyMembersList: !!lobbyMembersList,
                        positionSelection: !!positionSelection
                    });
                    
                    if (!lobbyState || !lobbyState.lobby_members || lobbyState.lobby_members.length === 0) {
                        console.log('ℹ️ No lobby members, hiding section');
                        lobbyMembers.classList.add('hidden');
                        return;
                    }
                    
                    console.log('✅ Showing lobby members section');
                    // Show lobby members section
                    lobbyMembers.classList.remove('hidden');
                    
                    // Render member list
                    lobbyMembersList.innerHTML = lobbyState.lobby_members.map(member => {
                        const leaderBadge = member.isLeader ? '<span style="color: #c8aa6e; font-weight: 700; margin-left: 4px;">👑</span>' : '';
                        const youBadge = member.isLocalPlayer ? '<span style="color: #0ac8b9; font-size: 10px; margin-left: 6px; padding: 2px 6px; background: rgba(10, 200, 185, 0.2); border-radius: 4px;">YOU</span>' : '';
                        
                        return `
                            <div style="display: flex; align-items: center; gap: 10px; padding: 10px; background: rgba(0, 0, 0, 0.3); border-radius: 6px; border: 1px solid rgba(200, 170, 110, 0.2);">
                                <div style="font-size: 20px;">👤</div>
                                <div style="flex: 1; min-width: 0;">
                                    <div style="font-size: 13px; font-weight: 600; color: ${member.isLocalPlayer ? '#0ac8b9' : '#f0e6d2'}; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        ${member.summonerName}${leaderBadge}${youBadge}
                                    </div>
                                </div>
                            </div>
                        `;
                    }).join('');
                    
                    // Show position selection for ranked queues (420, 440)
                    const queueId = lobbyState.queue_id;
                    console.log('🎯 Queue ID check:', {
                        queueId: queueId,
                        isRanked: queueId === 420 || queueId === 440,
                        willShowPositionSelection: queueId === 420 || queueId === 440
                    });
                    
                    if (queueId === 420 || queueId === 440) {
                        console.log('✅ Showing position selection for ranked queue');
                        positionSelection.classList.remove('hidden');
                        
                        // Populate current position preferences if available
                        const localPlayerPrefs = lobbyState.local_player_position_preferences;
                        console.log('🎯 Local player position preferences:', localPlayerPrefs);
                        
                        if (localPlayerPrefs) {
                            if (localPlayerPrefs.primaryPosition) {
                                document.getElementById('primaryPosition').value = localPlayerPrefs.primaryPosition;
                                console.log('✅ Set primary position:', localPlayerPrefs.primaryPosition);
                            }
                            if (localPlayerPrefs.secondaryPosition) {
                                document.getElementById('secondaryPosition').value = localPlayerPrefs.secondaryPosition;
                                console.log('✅ Set secondary position:', localPlayerPrefs.secondaryPosition);
                            }
                        }
                    } else {
                        console.log('ℹ️ Hiding position selection (not ranked queue)');
                        positionSelection.classList.add('hidden');
                    }
                }
                
                // Update position preferences
                async function updatePositionPreferences() {
                    const primary = document.getElementById('primaryPosition').value;
                    const secondary = document.getElementById('secondaryPosition').value;
                    
                    if (!primary || !secondary) {
                        console.log('⚠️ Both positions must be selected');
                        return;
                    }
                    
                    if (primary === secondary) {
                        showError('Primary and secondary positions must be different');
                        return;
                    }
                    
                    console.log('📤 Updating position preferences:', { primary, secondary });
                    
                    try {
                        const { error } = await supabaseClient
                            .from('remote_commands')
                            .insert([{
                                session_code: SESSION_CODE,
                                command_type: 'update_positions',
                                additional_data: {
                                    primary_position: primary,
                                    secondary_position: secondary
                                }
                            }]);
                        
                        if (error) throw error;
                        
                        showSuccess('Position preferences updated!');
                    } catch (error) {
                        console.error('❌ Failed to update positions:', error);
                        showError('Failed to update positions');
                    }
                }
                
                // Setup UI
                function setupUI() {
                    // Search
                    document.getElementById('championSearch').addEventListener('input', (e) => {
                        renderChampions(e.target.value);
                    });
                }
                
                // Start
                init();
            </script>
        <?php endif; ?>
        
        <!-- Autrex Footer -->
        <div class="autrex-footer">
            <p>Powered by <a href="https://autrex.kesug.com" target="_blank">Autrex</a></p>
            <p style="margin-top: 8px; font-size: 10px;">©2025 Autrex. All rights reserved.</p>
        </div>
    </div>
    
    <!-- QR Scanner Modal -->
    <div id="qrModal" class="qr-modal">
        <div class="qr-modal-content">
            <div class="qr-modal-header">
                <h3 class="qr-modal-title">📷 Scan QR Code</h3>
                <button class="qr-modal-close" onclick="closeQRScanner()">✕</button>
            </div>
            <div id="qr-reader"></div>
            <div id="qr-status" class="qr-status" style="display: none;"></div>
            <div style="margin-top: 16px; text-align: center; color: #5b5a56; font-size: 13px;">
                Point your camera at the QR code from Autrex desktop app
            </div>
        </div>
    </div>
    
    <script>
        let html5QrCode = null;
        
        function openQRScanner() {
            const modal = document.getElementById('qrModal');
            modal.classList.add('active');
            
            // Initialize QR scanner
            html5QrCode = new Html5Qrcode("qr-reader");
            
            const config = {
                fps: 10,
                qrbox: { width: 250, height: 250 },
                aspectRatio: 1.0
            };
            
            html5QrCode.start(
                { facingMode: "environment" },
                config,
                onScanSuccess,
                onScanError
            ).catch(err => {
                console.error('Failed to start QR scanner:', err);
                showQRStatus('Failed to access camera. Please check permissions.', 'error');
            });
        }
        
        function closeQRScanner() {
            const modal = document.getElementById('qrModal');
            modal.classList.remove('active');
            
            if (html5QrCode) {
                html5QrCode.stop().then(() => {
                    html5QrCode.clear();
                    html5QrCode = null;
                }).catch(err => {
                    console.error('Failed to stop QR scanner:', err);
                });
            }
        }
        
        function onScanSuccess(decodedText, decodedResult) {
            console.log('QR Code detected:', decodedText);
            
            // Extract session code from URL or direct code
            let sessionCode = '';
            
            // Check if it's a URL
            if (decodedText.includes('autrex.kesug.com/remote')) {
                const url = new URL(decodedText);
                sessionCode = url.searchParams.get('code');
            } else if (/^[A-Z0-9]{6}$/.test(decodedText)) {
                // Direct 6-character code
                sessionCode = decodedText;
            }
            
            if (sessionCode && /^[A-Z0-9]{6}$/.test(sessionCode)) {
                showQRStatus('✓ Code detected! Connecting...', 'success');
                
                // Stop scanner
                if (html5QrCode) {
                    html5QrCode.stop().then(() => {
                        // Redirect to remote control with code
                        window.location.href = '?code=' + sessionCode;
                    });
                }
            } else {
                showQRStatus('Invalid QR code. Please scan the code from Autrex app.', 'error');
            }
        }
        
        function onScanError(errorMessage) {
            // Ignore scan errors (happens frequently while scanning)
        }
        
        function showQRStatus(message, type) {
            const status = document.getElementById('qr-status');
            status.textContent = message;
            status.className = 'qr-status ' + type;
            status.style.display = 'block';
        }
        
        // Close modal on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeQRScanner();
            }
        });
    </script>
</body>
</html>
